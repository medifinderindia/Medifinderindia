-- Add missing columns to rider_kyc table for rejection reason and timestamp tracking
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS rejection_reason TEXT DEFAULT '';
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ;
