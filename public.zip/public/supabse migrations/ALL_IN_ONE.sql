-- ============================================================================
-- MEDIFINDER COMPLETE MIGRATION - FULLY IDEMPOTENT
-- ============================================================================
-- SAFE TO RUN 1 TIME, 2 TIMES, 19 TIMES, OR 100 TIMES
-- Every statement uses IF NOT EXISTS / IF EXISTS / CREATE OR REPLACE
-- Zero errors on re-run
-- ============================================================================

-- ============================================================================
-- SECTION 0: CLEANUP (drop broken triggers/functions)
-- ============================================================================
DO $$ BEGIN
    DROP TRIGGER IF EXISTS trg_bridge_rider_kyc ON public.admin_kyc_verifications CASCADE;
    DROP FUNCTION IF EXISTS public.bridge_rider_kyc_submission() CASCADE;
    DROP FUNCTION IF EXISTS public.handle_new_merchant_mapping_fallback() CASCADE;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
-- SECTION 1: FUNCTIONS
-- ============================================================================

-- is_admin()
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT
    coalesce(auth.email(), '') = 'medifinderindia@gmail.com'
    OR coalesce(auth.jwt() ->> 'phone', '') LIKE '%9593625498'
    OR coalesce(auth.jwt() ->> 'email', auth.email(), '') = 'medifinderindia@gmail.com'
$$;

-- updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- updated_at trigger for prescriptions
CREATE OR REPLACE FUNCTION update_prescriptions_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- SECTION 2: CORE TABLES (all CREATE TABLE IF NOT EXISTS)
-- ============================================================================

CREATE TABLE IF NOT EXISTS profiles (
    id TEXT PRIMARY KEY DEFAULT '',
    email TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    full_name TEXT DEFAULT '',
    role TEXT DEFAULT 'user',
    address TEXT DEFAULT '',
    city TEXT DEFAULT '',
    state TEXT DEFAULT '',
    pincode TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS patients (
    id TEXT PRIMARY KEY DEFAULT '',
    user_id TEXT,
    user_email TEXT DEFAULT '',
    name TEXT NOT NULL DEFAULT '',
    age TEXT DEFAULT '',
    gender TEXT DEFAULT '',
    relationship TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reminders (
    id TEXT PRIMARY KEY DEFAULT '',
    user_id TEXT,
    user_email TEXT DEFAULT '',
    patient_id TEXT,
    medicine_name TEXT NOT NULL DEFAULT '',
    medicine TEXT DEFAULT '',
    dosage TEXT DEFAULT '',
    frequency TEXT DEFAULT '',
    times TEXT[],
    time TEXT DEFAULT '',
    is_active BOOLEAN DEFAULT true,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS merchants (
    id BIGSERIAL PRIMARY KEY,
    auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    user_id UUID,
    email TEXT DEFAULT '',
    merchant_name TEXT DEFAULT '',
    shop_name TEXT DEFAULT '',
    owner_name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    merchant_avatar TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    license_status TEXT DEFAULT 'Unverified',
    license_id TEXT DEFAULT '',
    license_img TEXT DEFAULT '',
    bank_no TEXT DEFAULT '',
    ifsc_code TEXT DEFAULT '',
    upi_id TEXT DEFAULT '',
    bank_image TEXT DEFAULT '',
    pincode TEXT DEFAULT '',
    city TEXT DEFAULT '',
    district TEXT DEFAULT '',
    state TEXT DEFAULT '',
    address TEXT DEFAULT '',
    resolved_address TEXT DEFAULT '',
    latitude NUMERIC DEFAULT 22.5726,
    longitude NUMERIC DEFAULT 88.3639,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS medicines (
    id BIGSERIAL PRIMARY KEY,
    merchant_id BIGINT,
    shop_id TEXT,
    product_name TEXT NOT NULL DEFAULT '',
    name TEXT DEFAULT '',
    composition TEXT DEFAULT '',
    dosage_form TEXT DEFAULT '',
    dosage TEXT DEFAULT '',
    strength TEXT DEFAULT '',
    manufacturer TEXT DEFAULT '',
    prescription_req TEXT DEFAULT 'No',
    mfd_date DATE,
    expiry_date DATE,
    batch_number TEXT DEFAULT '',
    storage_condition TEXT DEFAULT '',
    unit_price NUMERIC DEFAULT 0,
    selling_price NUMERIC,
    mrp NUMERIC,
    drug_type TEXT DEFAULT '',
    stock_qty INTEGER DEFAULT 0,
    unit_type TEXT DEFAULT 'Strip',
    rack_location TEXT DEFAULT '',
    side_effects TEXT DEFAULT '',
    status TEXT DEFAULT 'Pending',
    admin_approved BOOLEAN DEFAULT false,
    image_url TEXT DEFAULT '',
    category TEXT DEFAULT 'Medicine',
    description TEXT DEFAULT '',
    rating NUMERIC DEFAULT 4.5,
    is_rx BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS prescriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT,
    user_email TEXT DEFAULT '',
    image_url TEXT DEFAULT '',
    status TEXT DEFAULT 'pending',
    notes TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS riders (
    id BIGSERIAL PRIMARY KEY,
    auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT DEFAULT '',
    full_name TEXT DEFAULT '',
    name TEXT DEFAULT '',
    username TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    status TEXT DEFAULT 'offline',
    duty_status TEXT DEFAULT 'offline',
    vehicle_type TEXT DEFAULT 'bike',
    vehicle_plate TEXT DEFAULT '',
    vehicle_number TEXT DEFAULT '',
    license_number TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    ifsc_code TEXT DEFAULT '',
    upi_id TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    is_verified BOOLEAN DEFAULT false,
    latitude NUMERIC DEFAULT 22.5726,
    longitude NUMERIC DEFAULT 88.3639,
    current_lat NUMERIC,
    current_lon NUMERIC,
    current_order_id UUID,
    rating NUMERIC DEFAULT 4.5,
    total_deliveries INTEGER DEFAULT 0,
    has_active_order BOOLEAN DEFAULT false,
    is_on_route BOOLEAN DEFAULT false,
    location_updated_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    user_id TEXT,
    user_email TEXT DEFAULT '',
    merchant_id BIGINT,
    rider_id BIGINT,
    customer_id UUID,
    customer_name TEXT DEFAULT '',
    customer_phone TEXT DEFAULT '',
    customer_address TEXT DEFAULT '',
    customer_email TEXT DEFAULT '',
    items JSONB DEFAULT '[]',
    items_text TEXT DEFAULT '',
    items_img TEXT DEFAULT '',
    address TEXT DEFAULT '',
    delivery_address TEXT DEFAULT '',
    payment_mode TEXT DEFAULT 'cod',
    payment_method TEXT DEFAULT 'cod',
    total_bill TEXT DEFAULT '',
    total_amount NUMERIC DEFAULT 0,
    total NUMERIC DEFAULT 0,
    final_amount NUMERIC DEFAULT 0,
    delivery_fee NUMERIC DEFAULT 0,
    delivery_charge NUMERIC DEFAULT 45,
    tax NUMERIC DEFAULT 0,
    discount NUMERIC DEFAULT 0,
    payment_status TEXT DEFAULT 'Pending',
    status TEXT DEFAULT 'pending',
    rx_verified BOOLEAN DEFAULT false,
    transit_mode TEXT DEFAULT '',
    vehicle_type TEXT DEFAULT '',
    eta_minutes INTEGER DEFAULT 30,
    shop_lat NUMERIC,
    shop_lng NUMERIC,
    pharmacy_lat NUMERIC,
    pharmacy_lon NUMERIC,
    pharmacy_name TEXT DEFAULT '',
    user_lat NUMERIC,
    user_lon NUMERIC,
    user_name TEXT DEFAULT '',
    user_phone TEXT DEFAULT '',
    rider_lat NUMERIC,
    rider_lon NUMERIC,
    location_updated_at TIMESTAMPTZ,
    delivery_secure_code TEXT DEFAULT '',
    customer_otp TEXT DEFAULT '',
    date_string TEXT DEFAULT '',
    cancellation_reason TEXT DEFAULT '',
    cancellation_note TEXT DEFAULT '',
    prescription_url TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    delivery_lat NUMERIC,
    delivery_lng NUMERIC,
    delivered_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cancelled_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    customer TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    reason TEXT DEFAULT '',
    payment TEXT DEFAULT '',
    status TEXT DEFAULT 'Pending',
    cancelled_by TEXT DEFAULT '',
    refund_amount NUMERIC DEFAULT 0,
    refunded_at TIMESTAMPTZ,
    user_email TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rx_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    user_id TEXT,
    prescription_url TEXT NOT NULL DEFAULT '',
    verified BOOLEAN DEFAULT false,
    verified_by TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    rx_status TEXT DEFAULT 'pending',
    rx_image TEXT DEFAULT '',
    medicine_name TEXT DEFAULT '',
    customer_name TEXT DEFAULT '',
    customer_phone TEXT DEFAULT '',
    doctor_name TEXT DEFAULT '',
    hospital_name TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    approved_at TIMESTAMPTZ,
    approved_by TEXT DEFAULT '',
    rejected_at TIMESTAMPTZ,
    rejection_reason TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rider_kyc (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    name TEXT DEFAULT '',
    license_no TEXT DEFAULT '',
    plate_no TEXT DEFAULT '',
    license_img TEXT DEFAULT '',
    plate_img TEXT DEFAULT '',
    aadhaar_number TEXT DEFAULT '',
    aadhaar_img TEXT DEFAULT '',
    pan_number TEXT DEFAULT '',
    pan_img TEXT DEFAULT '',
    vehicle_rc TEXT DEFAULT '',
    vehicle_img TEXT DEFAULT '',
    insurance_img TEXT DEFAULT '',
    verified BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rider_payouts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    name TEXT DEFAULT '',
    contact TEXT DEFAULT '',
    hours TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    destination TEXT DEFAULT '',
    paid BOOLEAN DEFAULT false,
    status TEXT DEFAULT 'pending',
    upi_id TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    ifsc TEXT DEFAULT '',
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_kyc_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    merchant_id BIGINT,
    kyc_type TEXT DEFAULT '',
    data_payload JSONB DEFAULT '{}',
    status TEXT DEFAULT 'pending',
    submitted_at TIMESTAMPTZ DEFAULT NOW(),
    verified_at TIMESTAMPTZ,
    admin_notes TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS admin_payout_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    entity_type TEXT DEFAULT '',
    entity_id UUID,
    total_payout_amount NUMERIC DEFAULT 0,
    active_duty_hours NUMERIC DEFAULT 0,
    request_status TEXT DEFAULT 'pending',
    requested_at TIMESTAMPTZ DEFAULT NOW(),
    amount NUMERIC DEFAULT 0,
    status TEXT DEFAULT 'pending',
    upi_id TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    ifsc TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    processed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payout_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id TEXT DEFAULT '',
    recipient_name TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    entity_type TEXT DEFAULT '',
    entity_id UUID,
    type TEXT DEFAULT '',
    payment_method TEXT DEFAULT 'Bank Transfer',
    method TEXT DEFAULT '',
    status TEXT DEFAULT 'Completed',
    reference TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS riders_wallet (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    order_id TEXT,
    amount_earned NUMERIC DEFAULT 0,
    balance NUMERIC DEFAULT 0,
    total_earned NUMERIC DEFAULT 0,
    total_withdrawn NUMERIC DEFAULT 0,
    status TEXT DEFAULT 'success',
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS service_zones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT DEFAULT '',
    pin TEXT DEFAULT '',
    dist TEXT DEFAULT '',
    ps TEXT DEFAULT '',
    muni TEXT DEFAULT '',
    state TEXT DEFAULT '',
    city TEXT DEFAULT '',
    pincode TEXT DEFAULT '',
    riders INTEGER DEFAULT 0,
    merchants INTEGER DEFAULT 0,
    users INTEGER DEFAULT 0,
    status TEXT DEFAULT 'approved',
    outage_message TEXT DEFAULT '',
    outage_start TIMESTAMPTZ,
    radius_km NUMERIC DEFAULT 10,
    center_lat NUMERIC DEFAULT 22.5726,
    center_lng NUMERIC DEFAULT 88.3639,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS delivery_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    merchant_id BIGINT,
    rider_id BIGINT,
    status TEXT DEFAULT 'broadcasted',
    pickup_address TEXT DEFAULT '',
    drop_address TEXT DEFAULT '',
    delivery_charge NUMERIC DEFAULT 45,
    vehicle_type TEXT DEFAULT 'bike',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    accepted_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS offers (
    id BIGSERIAL PRIMARY KEY,
    merchant_id BIGINT,
    title TEXT DEFAULT '',
    description TEXT DEFAULT '',
    text TEXT DEFAULT '',
    discount_type TEXT DEFAULT 'percentage',
    discount_value NUMERIC DEFAULT 0,
    min_order NUMERIC DEFAULT 0,
    max_discount NUMERIC DEFAULT 0,
    code TEXT DEFAULT '',
    status TEXT DEFAULT 'inactive',
    active BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    expiry TEXT DEFAULT '',
    start_date TIMESTAMPTZ DEFAULT NOW(),
    end_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS checkups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT DEFAULT '',
    name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    topic TEXT DEFAULT '',
    type TEXT DEFAULT '',
    date DATE,
    result TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target TEXT DEFAULT 'all',
    user_id TEXT DEFAULT '',
    title TEXT NOT NULL DEFAULT '',
    message TEXT DEFAULT '',
    text TEXT DEFAULT '',
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS merchant_kyc (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    license_img TEXT DEFAULT '',
    license_no TEXT DEFAULT '',
    verified BOOLEAN DEFAULT false,
    rejection_reason TEXT DEFAULT '',
    rejected_at TIMESTAMPTZ,
    verified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS merchant_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target_audience TEXT DEFAULT 'all',
    shop_id TEXT DEFAULT '',
    merchant_id BIGINT,
    title TEXT NOT NULL DEFAULT '',
    message TEXT DEFAULT '',
    type TEXT DEFAULT 'info',
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS merchant_payouts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    order_id TEXT DEFAULT '',
    shop_id TEXT DEFAULT '',
    pickup_address TEXT DEFAULT '',
    drop_address TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    payment_mode TEXT DEFAULT 'Online Transfer',
    status TEXT DEFAULT 'Pending',
    settled_at TIMESTAMPTZ,
    upi_id TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    ifsc TEXT DEFAULT '',
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rider_notifications (
    id BIGSERIAL PRIMARY KEY,
    rider_id BIGINT,
    title TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL DEFAULT '',
    type TEXT DEFAULT 'info',
    broadcast_to TEXT DEFAULT 'individual',
    target TEXT DEFAULT 'individual',
    created_by TEXT DEFAULT 'admin',
    sent_by TEXT DEFAULT 'admin',
    is_read BOOLEAN DEFAULT false,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS analytics (
    id BIGSERIAL PRIMARY KEY,
    metric_type TEXT DEFAULT '',
    metric_value NUMERIC(15,2),
    metric_date DATE,
    event_type TEXT DEFAULT '',
    entity_type TEXT DEFAULT '',
    entity_id UUID,
    data JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    medicine_id BIGINT,
    merchant_id BIGINT,
    product_name TEXT NOT NULL DEFAULT '',
    product_image TEXT DEFAULT '',
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10,2) DEFAULT 0,
    total_price DECIMAL(10,2) DEFAULT 0,
    discount DECIMAL(10,2) DEFAULT 0,
    tax DECIMAL(10,2) DEFAULT 0,
    batch_number TEXT DEFAULT '',
    expiry_date TEXT DEFAULT '',
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS returns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    order_item_id UUID,
    merchant_id BIGINT,
    customer_id TEXT,
    reason TEXT NOT NULL DEFAULT '',
    description TEXT DEFAULT '',
    customer_photos TEXT[],
    status TEXT DEFAULT 'pending',
    refund_amount DECIMAL(10,2) DEFAULT 0,
    refund_method TEXT DEFAULT '',
    refund_status TEXT DEFAULT 'pending',
    refund_processed_at TIMESTAMPTZ,
    return_pickup_date TIMESTAMPTZ,
    return_received_date TIMESTAMPTZ,
    admin_notes TEXT DEFAULT '',
    merchant_notes TEXT DEFAULT '',
    date_requested TIMESTAMPTZ DEFAULT NOW(),
    timeline JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS coupons (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    code TEXT NOT NULL DEFAULT '',
    description TEXT DEFAULT '',
    discount_type TEXT DEFAULT 'percentage',
    discount_value DECIMAL(10,2) DEFAULT 0,
    min_order_amount DECIMAL(10,2) DEFAULT 0,
    max_discount_amount DECIMAL(10,2),
    max_uses INT DEFAULT 100,
    used_count INT DEFAULT 0,
    applicable_products UUID[],
    applicable_categories TEXT[],
    start_date TIMESTAMPTZ DEFAULT NOW(),
    end_date TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS promotions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    type TEXT DEFAULT 'discount',
    title TEXT NOT NULL DEFAULT '',
    description TEXT DEFAULT '',
    banner_image TEXT DEFAULT '',
    discount_type TEXT DEFAULT '',
    discount_value DECIMAL(10,2) DEFAULT 0,
    applicable_products UUID[],
    applicable_categories TEXT[],
    start_date TIMESTAMPTZ NOT NULL,
    end_date TIMESTAMPTZ NOT NULL,
    status TEXT DEFAULT 'active',
    budget DECIMAL(10,2) DEFAULT 0,
    spent DECIMAL(10,2) DEFAULT 0,
    impressions INT DEFAULT 0,
    clicks INT DEFAULT 0,
    conversions INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS customer_communications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    customer_id TEXT,
    order_id TEXT,
    message TEXT NOT NULL DEFAULT '',
    subject TEXT DEFAULT '',
    type TEXT DEFAULT 'order_update',
    channel TEXT DEFAULT 'in_app',
    is_read BOOLEAN DEFAULT false,
    sent_by TEXT DEFAULT 'merchant',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS stock_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    medicine_id BIGINT,
    merchant_id BIGINT,
    change_type TEXT NOT NULL DEFAULT '',
    quantity_change INT DEFAULT 0,
    previous_stock INT DEFAULT 0,
    new_stock INT DEFAULT 0,
    reason TEXT DEFAULT '',
    batch_number TEXT DEFAULT '',
    performed_by TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS product_views (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    medicine_id BIGINT,
    merchant_id BIGINT,
    viewer_id TEXT,
    viewer_ip TEXT,
    viewer_device TEXT,
    source TEXT DEFAULT 'direct',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS merchant_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    date DATE DEFAULT CURRENT_DATE,
    total_orders INT DEFAULT 0,
    total_revenue DECIMAL(10,2) DEFAULT 0,
    total_items_sold INT DEFAULT 0,
    new_customers INT DEFAULT 0,
    returning_customers INT DEFAULT 0,
    returns_count INT DEFAULT 0,
    refunds_amount DECIMAL(10,2) DEFAULT 0,
    avg_order_value DECIMAL(10,2) DEFAULT 0,
    conversion_rate DECIMAL(5,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(merchant_id, date)
);

CREATE TABLE IF NOT EXISTS product_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    name TEXT NOT NULL DEFAULT '',
    description TEXT DEFAULT '',
    icon TEXT DEFAULT '',
    is_active BOOLEAN DEFAULT true,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS merchant_notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    title TEXT NOT NULL DEFAULT '',
    message TEXT DEFAULT '',
    type TEXT DEFAULT 'info',
    category TEXT DEFAULT 'general',
    reference_id UUID,
    reference_type TEXT DEFAULT '',
    is_read BOOLEAN DEFAULT false,
    action_url TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    name TEXT NOT NULL DEFAULT '',
    price DECIMAL(10,2) DEFAULT 0,
    mrp DECIMAL(10,2) DEFAULT 0,
    category TEXT DEFAULT '',
    stock INT DEFAULT 0,
    image_url TEXT DEFAULT '',
    description TEXT DEFAULT '',
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID,
    user_id TEXT DEFAULT '',
    rating INT DEFAULT 5,
    review_text TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS price_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID,
    merchant_id BIGINT,
    new_price DECIMAL(10,2) DEFAULT 0,
    old_price DECIMAL(10,2) DEFAULT 0,
    change_type TEXT DEFAULT '',
    change_value DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sponsored_products (
    id BIGSERIAL PRIMARY KEY,
    title TEXT NOT NULL DEFAULT '',
    subtitle TEXT DEFAULT '',
    tag TEXT DEFAULT '',
    gradient TEXT DEFAULT 'linear-gradient(135deg, #e02020, #ff6b6b)',
    icon_class TEXT DEFAULT 'fas fa-tag',
    btn_text TEXT DEFAULT 'Shop Now',
    btn_action TEXT DEFAULT '',
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- SECTION 3: ADD COLUMNS IF NOT EXIST (idempotent ALTER TABLE)
-- ============================================================================

DO $$ BEGIN
    ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS shop_id TEXT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS product_name TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS name TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS composition TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS dosage_form TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS strength TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS manufacturer TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS prescription_req TEXT DEFAULT 'No';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS mfd_date DATE;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS expiry_date DATE;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS batch_number TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS storage_condition TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS unit_price NUMERIC DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS selling_price NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS mrp NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS drug_type TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS stock_qty INTEGER DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS unit_type TEXT DEFAULT 'Strip';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS rack_location TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS side_effects TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Pending';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS admin_approved BOOLEAN DEFAULT false;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS image_url TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'Medicine';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS description TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS rating NUMERIC DEFAULT 4.5;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS is_rx BOOLEAN DEFAULT false;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS dosage TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- orders columns
DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS order_id TEXT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_id TEXT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_email TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rider_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_id UUID;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_name TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_phone TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_address TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_email TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items JSONB DEFAULT '[]';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items_text TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items_img TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS address TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_address TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_mode TEXT DEFAULT 'cod';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_method TEXT DEFAULT 'cod';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total_bill TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total_amount NUMERIC DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total NUMERIC DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS final_amount NUMERIC DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_fee NUMERIC DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_charge NUMERIC DEFAULT 45;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tax NUMERIC DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS discount NUMERIC DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'Pending';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rx_verified BOOLEAN DEFAULT false;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS transit_mode TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vehicle_type TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS eta_minutes INTEGER DEFAULT 30;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS shop_lat NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS shop_lng NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS pharmacy_lat NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS pharmacy_lon NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS pharmacy_name TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_lat NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_lon NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_name TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_phone TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rider_lat NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rider_lon NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS location_updated_at TIMESTAMPTZ;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_secure_code TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_otp TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS date_string TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancellation_reason TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancellation_note TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS prescription_url TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_lat NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_lng NUMERIC;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMPTZ;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- order_items columns
DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS order_id TEXT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS medicine_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS product_name TEXT NOT NULL DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS product_image TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS quantity INT DEFAULT 1;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS unit_price DECIMAL(10,2) DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS total_price DECIMAL(10,2) DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS discount DECIMAL(10,2) DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS tax DECIMAL(10,2) DEFAULT 0;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS batch_number TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS expiry_date TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- merchant_kyc columns
DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS license_img TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS license_no TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS verified BOOLEAN DEFAULT false;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS rejection_reason TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- merchant_kyc extra columns
DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS kyc_type TEXT DEFAULT 'license';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS aadhaar_number TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS aadhaar_img TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS pan_number TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS pan_img TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- rider_notifications extra columns
DO $$ BEGIN
    ALTER TABLE public.rider_notifications ADD COLUMN IF NOT EXISTS target TEXT DEFAULT 'individual';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.rider_notifications ADD COLUMN IF NOT EXISTS sent_by TEXT DEFAULT 'admin';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- cancelled_orders columns
DO $$ BEGIN
    ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS order_id TEXT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS user_email TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- offers columns
DO $$ BEGIN
    ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- returns columns
DO $$ BEGIN
    ALTER TABLE public.returns ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- coupons columns
DO $$ BEGIN
    ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- promotions columns
DO $$ BEGIN
    ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- stock_history columns
DO $$ BEGIN
    ALTER TABLE public.stock_history ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- product_views columns
DO $$ BEGIN
    ALTER TABLE public.product_views ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- merchant_payouts columns
DO $$ BEGIN
    ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- merchant_alerts columns
DO $$ BEGIN
    ALTER TABLE public.merchant_alerts ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- admin_kyc_verifications columns
DO $$ BEGIN
    ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS rider_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- prescriptions columns
DO $$ BEGIN
    ALTER TABLE public.prescriptions ADD COLUMN IF NOT EXISTS user_id TEXT;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.prescriptions ADD COLUMN IF NOT EXISTS user_email TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE public.prescriptions ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- ============================================================================
-- SECTION 4: VIEWS
-- ============================================================================

DROP VIEW IF EXISTS public.partner_medicines CASCADE;
CREATE OR REPLACE VIEW public.partner_medicines AS
SELECT
    m.id,
    m.merchant_id,
    m.product_name,
    m.name,
    m.composition,
    m.dosage_form,
    m.strength,
    m.manufacturer,
    m.unit_price,
    m.selling_price,
    m.mrp,
    m.drug_type,
    m.stock_qty,
    m.image_url,
    m.category,
    m.description,
    m.rating,
    m.status,
    CASE WHEN m.status IN ('Approved','Active') THEN true ELSE false END AS approved,
    COALESCE(m.selling_price, m.unit_price, m.mrp, 0) AS price,
    COALESCE(m.is_rx, false) AS is_rx,
    COALESCE(m.expiry_date::text, '') AS expiry,
    COALESCE(m.image_url, '') AS img,
    COALESCE(m.merchant_id, 0) AS merchantId,
    COALESCE(m.description, '') AS "desc",
    COALESCE(m.stock_qty, 0) AS stock,
    mc.shop_name,
    mc.city,
    mc.address
FROM public.medicines m
JOIN public.merchants mc ON mc.id = m.merchant_id
WHERE m.status IN ('Approved', 'Active');

-- ============================================================================
-- SECTION 5: INDEXES (CREATE INDEX IF NOT EXISTS)
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_phone ON public.profiles(phone);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_patients_user ON public.patients(user_id);
CREATE INDEX IF NOT EXISTS idx_reminders_user ON public.reminders(user_id);
CREATE INDEX IF NOT EXISTS idx_merchants_auth ON public.merchants(auth_user_id);
CREATE INDEX IF NOT EXISTS idx_merchants_email ON public.merchants(email);
CREATE INDEX IF NOT EXISTS idx_medicines_merchant ON public.medicines(merchant_id);
CREATE INDEX IF NOT EXISTS idx_medicines_status ON public.medicines(status);
CREATE INDEX IF NOT EXISTS idx_medicines_category ON public.medicines(category);
CREATE INDEX IF NOT EXISTS idx_riders_auth ON public.riders(auth_user_id);
CREATE INDEX IF NOT EXISTS idx_riders_email ON public.riders(email);
CREATE INDEX IF NOT EXISTS idx_orders_merchant ON public.orders(merchant_id);
CREATE INDEX IF NOT EXISTS idx_orders_rider ON public.orders(rider_id);
CREATE INDEX IF NOT EXISTS idx_orders_user ON public.orders(user_email);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_merchant ON public.order_items(merchant_id);
CREATE INDEX IF NOT EXISTS idx_merchant_kyc_merchant ON public.merchant_kyc(merchant_id);
CREATE INDEX IF NOT EXISTS idx_rider_kyc_rider ON public.rider_kyc(rider_id);
CREATE INDEX IF NOT EXISTS idx_rider_payouts_rider ON public.rider_payouts(rider_id);
CREATE INDEX IF NOT EXISTS idx_admin_kyc_rider ON public.admin_kyc_verifications(rider_id);
CREATE INDEX IF NOT EXISTS idx_admin_kyc_merchant ON public.admin_kyc_verifications(merchant_id);
CREATE INDEX IF NOT EXISTS idx_merchant_alerts_merchant ON public.merchant_alerts(merchant_id);
CREATE INDEX IF NOT EXISTS idx_delivery_requests_order ON public.delivery_requests(order_id);
CREATE INDEX IF NOT EXISTS idx_delivery_requests_status ON public.delivery_requests(status);
CREATE INDEX IF NOT EXISTS idx_merchant_payouts_merchant ON public.merchant_payouts(merchant_id);
CREATE INDEX IF NOT EXISTS idx_returns_merchant ON public.returns(merchant_id);
CREATE INDEX IF NOT EXISTS idx_returns_order ON public.returns(order_id);
CREATE INDEX IF NOT EXISTS idx_coupons_merchant ON public.coupons(merchant_id);
CREATE INDEX IF NOT EXISTS idx_coupons_code ON public.coupons(code);
CREATE INDEX IF NOT EXISTS idx_promotions_merchant ON public.promotions(merchant_id);
CREATE INDEX IF NOT EXISTS idx_stock_history_merchant ON public.stock_history(merchant_id);
CREATE INDEX IF NOT EXISTS idx_stock_history_medicine ON public.stock_history(medicine_id);
CREATE INDEX IF NOT EXISTS idx_product_views_merchant ON public.product_views(merchant_id);
CREATE INDEX IF NOT EXISTS idx_product_views_medicine ON public.product_views(medicine_id);
CREATE INDEX IF NOT EXISTS idx_merchant_analytics_merchant ON public.merchant_analytics(merchant_id);
CREATE INDEX IF NOT EXISTS idx_merchant_notif_merchant ON public.merchant_notifications(merchant_id);
CREATE INDEX IF NOT EXISTS idx_customer_comms_merchant ON public.customer_communications(merchant_id);
CREATE INDEX IF NOT EXISTS idx_products_merchant ON public.products(merchant_id);
CREATE INDEX IF NOT EXISTS idx_price_history_merchant ON public.price_history(merchant_id);
CREATE INDEX IF NOT EXISTS idx_price_history_product ON public.price_history(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON public.reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_rider_notifications_rider ON public.rider_notifications(rider_id);
CREATE INDEX IF NOT EXISTS idx_riders_wallet_rider ON public.riders_wallet(rider_id);
CREATE INDEX IF NOT EXISTS idx_payout_history_entity ON public.payout_history(entity_id);
CREATE INDEX IF NOT EXISTS idx_admin_payout_requests_rider ON public.admin_payout_requests(rider_id);
CREATE INDEX IF NOT EXISTS idx_analytics_date ON public.analytics(metric_date);
CREATE INDEX IF NOT EXISTS idx_cancelled_orders_order_id ON public.cancelled_orders(order_id);
CREATE INDEX IF NOT EXISTS idx_cancelled_orders_user_email ON public.cancelled_orders(user_email);
CREATE INDEX IF NOT EXISTS idx_service_zones_pin ON public.service_zones(pin);
CREATE INDEX IF NOT EXISTS idx_sponsored_products_active ON public.sponsored_products(is_active);
CREATE INDEX IF NOT EXISTS idx_sponsored_products_sort ON public.sponsored_products(sort_order);

-- UNIQUE constraints (needed for upsert)
DO $$ BEGIN
    ALTER TABLE public.merchants ADD CONSTRAINT uq_merchants_auth_user_id UNIQUE (auth_user_id);
EXCEPTION WHEN OTHERS THEN NULL; END $$;
DO $$ BEGIN
    ALTER TABLE public.riders ADD CONSTRAINT uq_riders_auth_user_id UNIQUE (auth_user_id);
EXCEPTION WHEN OTHERS THEN NULL; END $$;
DO $$ BEGIN
    DROP INDEX IF EXISTS idx_uq_riders_email;
EXCEPTION WHEN OTHERS THEN NULL; END $$;
CREATE UNIQUE INDEX IF NOT EXISTS idx_uq_riders_email ON public.riders (email) WHERE email != '';

-- Additional missing indexes
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_prescriptions_user_id ON public.prescriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_user_email ON public.prescriptions(user_email);
CREATE INDEX IF NOT EXISTS idx_rider_notif_read ON public.rider_notifications(rider_id, is_read);
CREATE INDEX IF NOT EXISTS idx_medicines_merchant_status ON public.medicines(merchant_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_merchant_status ON public.orders(merchant_id, status);
CREATE INDEX IF NOT EXISTS idx_riders_wallet_rider_created ON public.riders_wallet(rider_id, created_at DESC);

-- ============================================================================
-- SECTION 6: TRIGGERS (DROP IF EXISTS then CREATE)
-- ============================================================================

-- updated_at triggers
DROP TRIGGER IF EXISTS update_medicines_updated_at ON public.medicines;
CREATE TRIGGER update_medicines_updated_at BEFORE UPDATE ON public.medicines FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_orders_updated_at ON public.orders;
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_returns_updated_at ON public.returns;
CREATE TRIGGER update_returns_updated_at BEFORE UPDATE ON public.returns FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_products_updated_at ON public.products;
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_riders_updated_at ON public.riders;
CREATE TRIGGER update_riders_updated_at BEFORE UPDATE ON public.riders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_merchants_updated_at ON public.merchants;
CREATE TRIGGER update_merchants_updated_at BEFORE UPDATE ON public.merchants FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_riders_wallet_updated_at ON public.riders_wallet;
CREATE TRIGGER update_riders_wallet_updated_at BEFORE UPDATE ON public.riders_wallet FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- SECTION 7: TRIGGER FUNCTIONS
-- ============================================================================

-- sync_medicine_fields trigger function
CREATE OR REPLACE FUNCTION public.sync_medicine_fields()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.name IS NULL OR NEW.name = '' THEN
        NEW.name := NEW.product_name;
    END IF;
    IF NEW.dosage IS NULL OR NEW.dosage = '' THEN
        NEW.dosage := NEW.dosage_form;
    END IF;
    IF NEW.shop_id IS NULL THEN
        NEW.shop_id := NEW.merchant_id::text;
    END IF;
    IF NEW.is_rx IS NULL THEN
        NEW.is_rx := (NEW.prescription_req = 'Yes');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_medicine_fields ON public.medicines;
CREATE TRIGGER trg_sync_medicine_fields
BEFORE INSERT OR UPDATE ON public.medicines
FOR EACH ROW EXECUTE FUNCTION public.sync_medicine_fields();

-- log_stock_change trigger function
CREATE OR REPLACE FUNCTION public.log_stock_change()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.stock_qty IS DISTINCT FROM NEW.stock_qty THEN
        INSERT INTO public.stock_history (medicine_id, merchant_id, change_type, quantity_change, previous_stock, new_stock, reason, performed_by)
        VALUES (NEW.id, NEW.merchant_id, CASE WHEN NEW.stock_qty > OLD.stock_qty THEN 'restock' ELSE 'sale' END, NEW.stock_qty - OLD.stock_qty, OLD.stock_qty, NEW.stock_qty, 'Auto-logged', 'system');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_log_stock_change ON public.medicines;
CREATE TRIGGER trigger_log_stock_change AFTER UPDATE ON public.medicines FOR EACH ROW EXECUTE FUNCTION log_stock_change();

-- update_order_analytics trigger function
CREATE OR REPLACE FUNCTION public.update_order_analytics()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'delivered' AND (OLD.status IS NULL OR OLD.status != 'delivered') THEN
        INSERT INTO public.merchant_analytics (merchant_id, date, total_orders, total_revenue, total_items_sold)
        VALUES (NEW.merchant_id, CURRENT_DATE, 1, COALESCE(NEW.total_amount, 0), 1)
        ON CONFLICT (merchant_id, date)
        DO UPDATE SET
            total_orders = public.merchant_analytics.total_orders + 1,
            total_revenue = public.merchant_analytics.total_revenue + COALESCE(NEW.total_amount, 0),
            total_items_sold = public.merchant_analytics.total_items_sold + 1;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_order_analytics ON public.orders;
CREATE TRIGGER trigger_update_order_analytics AFTER UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION update_order_analytics();

-- ============================================================================
-- SECTION 8: RLS DISABLE/ENABLE + CLEANUP
-- ============================================================================

ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.patients DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.reminders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchants DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.medicines DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.cancelled_orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rx_orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_kyc DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_payouts DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_kyc_verifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_payout_requests DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.payout_history DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders_wallet DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_zones DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.checkups DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_kyc DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_alerts DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_payouts DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.returns DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupons DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_communications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_history DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_views DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_analytics DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.products DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.price_history DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.sponsored_products DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_requests DISABLE ROW LEVEL SECURITY;

-- Drop all old policies first
DO $$ DECLARE r RECORD;
BEGIN
    FOR r IN (SELECT schemaname, tablename, policyname FROM pg_policies WHERE schemaname = 'public') LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', r.policyname, r.schemaname, r.tablename);
    END LOOP;
END $$;

-- Re-enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medicines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cancelled_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rx_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_kyc ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_payouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_kyc_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_payout_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payout_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders_wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checkups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_kyc ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_payouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.returns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_communications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.price_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sponsored_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_requests ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- SECTION 9: RLS POLICIES (DROP IF EXISTS + CREATE)
-- ============================================================================

-- profiles
CREATE POLICY "profiles_sel" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_ins" ON public.profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "profiles_upd" ON public.profiles FOR UPDATE USING (
    public.is_admin() OR id = auth.uid()::text OR id = auth.email()
);

-- patients (scoped to own)
CREATE POLICY "patients_all" ON public.patients FOR ALL
  USING (user_email = auth.email() OR public.is_admin())
  WITH CHECK (user_email = auth.email() OR public.is_admin());

-- reminders (scoped to own)
CREATE POLICY "reminders_all" ON public.reminders FOR ALL
  USING (user_email = auth.email() OR public.is_admin())
  WITH CHECK (user_email = auth.email() OR public.is_admin());

-- merchants
CREATE POLICY "merchants_sel" ON public.merchants FOR SELECT USING (true);
CREATE POLICY "merchants_ins" ON public.merchants FOR INSERT WITH CHECK (true);
CREATE POLICY "merchants_upd" ON public.merchants FOR UPDATE USING (
    public.is_admin()
    OR auth_user_id = auth.uid()
    OR email = coalesce(auth.email(), '')
    OR phone = coalesce(auth.jwt() ->> 'phone', '')
);

-- medicines
CREATE POLICY "meds_sel" ON public.medicines FOR SELECT
  USING (status IN ('Approved','Active') OR public.is_admin()
    OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));
CREATE POLICY "meds_all" ON public.medicines FOR ALL
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()))
  WITH CHECK (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));

-- riders
CREATE POLICY "riders_sel" ON public.riders FOR SELECT USING (true);
CREATE POLICY "riders_ins" ON public.riders FOR INSERT WITH CHECK (true);
CREATE POLICY "riders_upd" ON public.riders FOR UPDATE USING (public.is_admin() OR auth_user_id = auth.uid());

-- orders
CREATE POLICY "orders_sel" ON public.orders FOR SELECT
  USING (public.is_admin() OR user_email = auth.email()
    OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email())
    OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
CREATE POLICY "orders_ins" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "orders_upd" ON public.orders FOR UPDATE
  USING (public.is_admin() OR user_email = auth.email()
    OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email())
    OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
CREATE POLICY "orders_del" ON public.orders FOR DELETE
  USING (public.is_admin() OR user_email = auth.email());

-- cancelled_orders
CREATE POLICY "co_sel" ON public.cancelled_orders FOR SELECT
  USING (public.is_admin() OR user_email = auth.email());
CREATE POLICY "co_upd" ON public.cancelled_orders FOR UPDATE USING (public.is_admin());

-- rx_orders
CREATE POLICY "rx_sel" ON public.rx_orders FOR SELECT USING (public.is_admin());
CREATE POLICY "rx_ins" ON public.rx_orders FOR INSERT WITH CHECK (true);
CREATE POLICY "rx_upd" ON public.rx_orders FOR UPDATE USING (public.is_admin());

-- order_items
CREATE POLICY "oi_sel" ON public.order_items FOR SELECT
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
CREATE POLICY "oi_ins" ON public.order_items FOR INSERT WITH CHECK (true);
CREATE POLICY "oi_upd" ON public.order_items FOR UPDATE
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));

-- rider_kyc
CREATE POLICY "rk_sel" ON public.rider_kyc FOR SELECT USING (public.is_admin());
CREATE POLICY "rk_ins" ON public.rider_kyc FOR INSERT WITH CHECK (true);
CREATE POLICY "rk_upd" ON public.rider_kyc FOR UPDATE USING (public.is_admin());

-- rider_payouts
CREATE POLICY "rp_sel" ON public.rider_payouts FOR SELECT USING (public.is_admin());
CREATE POLICY "rp_ins" ON public.rider_payouts FOR INSERT WITH CHECK (true);
CREATE POLICY "rp_upd" ON public.rider_payouts FOR UPDATE USING (public.is_admin());

-- admin_kyc_verifications
CREATE POLICY "akv_sel" ON public.admin_kyc_verifications FOR SELECT USING (public.is_admin());
CREATE POLICY "akv_ins" ON public.admin_kyc_verifications FOR INSERT WITH CHECK (true);
CREATE POLICY "akv_upd" ON public.admin_kyc_verifications FOR UPDATE USING (public.is_admin());

-- admin_payout_requests
CREATE POLICY "apr_sel" ON public.admin_payout_requests FOR SELECT USING (public.is_admin());
CREATE POLICY "apr_ins" ON public.admin_payout_requests FOR INSERT WITH CHECK (true);

-- payout_history
CREATE POLICY "ph_sel" ON public.payout_history FOR SELECT USING (public.is_admin());
CREATE POLICY "ph_ins" ON public.payout_history FOR INSERT WITH CHECK (public.is_admin());

-- riders_wallet
CREATE POLICY "rw_sel" ON public.riders_wallet FOR SELECT
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid()));
CREATE POLICY "rw_ins" ON public.riders_wallet FOR INSERT WITH CHECK (true);
CREATE POLICY "rw_upd" ON public.riders_wallet FOR UPDATE
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid()));

-- service_zones (admin only for write)
CREATE POLICY "sz_sel" ON public.service_zones FOR SELECT USING (true);
CREATE POLICY "sz_ins" ON public.service_zones FOR INSERT WITH CHECK (public.is_admin());
CREATE POLICY "sz_upd" ON public.service_zones FOR UPDATE USING (public.is_admin());

-- offers
CREATE POLICY "offers_sel" ON public.offers FOR SELECT USING (true);
CREATE POLICY "offers_ins" ON public.offers FOR INSERT WITH CHECK (public.is_admin());
CREATE POLICY "offers_upd" ON public.offers FOR UPDATE USING (public.is_admin());

-- checkups
CREATE POLICY "checkups_ins" ON public.checkups FOR INSERT WITH CHECK ((SELECT auth.uid()) IS NOT NULL);
CREATE POLICY "checkups_sel" ON public.checkups FOR SELECT USING (public.is_admin());

-- notifications (admin only write)
CREATE POLICY "notif_sel" ON public.notifications FOR SELECT USING (true);
CREATE POLICY "notif_ins" ON public.notifications FOR INSERT WITH CHECK (public.is_admin());

-- merchant_kyc
CREATE POLICY "mkyc_sel" ON public.merchant_kyc FOR SELECT
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));
CREATE POLICY "mkyc_ins" ON public.merchant_kyc FOR INSERT WITH CHECK (true);
CREATE POLICY "mkyc_upd" ON public.merchant_kyc FOR UPDATE
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));

-- merchant_alerts
CREATE POLICY "malert_sel" ON public.merchant_alerts FOR SELECT USING (true);
CREATE POLICY "malert_ins" ON public.merchant_alerts FOR INSERT WITH CHECK (true);

-- merchant_payouts
CREATE POLICY "mpay_sel" ON public.merchant_payouts FOR SELECT
  USING (public.is_admin() OR shop_id IN (SELECT id::text FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));
CREATE POLICY "mpay_upd" ON public.merchant_payouts FOR UPDATE USING (public.is_admin());

-- rider_notifications
CREATE POLICY "rn_sel" ON public.rider_notifications FOR SELECT USING (true);
CREATE POLICY "rn_ins" ON public.rider_notifications FOR INSERT WITH CHECK (true);
CREATE POLICY "rn_upd" ON public.rider_notifications FOR UPDATE
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid()));

-- delivery_requests
CREATE POLICY "dreq_sel" ON public.delivery_requests FOR SELECT USING (true);
CREATE POLICY "dreq_ins" ON public.delivery_requests FOR INSERT WITH CHECK (true);
CREATE POLICY "dreq_upd" ON public.delivery_requests FOR UPDATE USING (true);
CREATE POLICY "dreq_del" ON public.delivery_requests FOR DELETE USING (public.is_admin());

-- returns
CREATE POLICY "ret_sel" ON public.returns FOR SELECT
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
CREATE POLICY "ret_ins" ON public.returns FOR INSERT WITH CHECK (true);

-- coupons
CREATE POLICY "coup_sel" ON public.coupons FOR SELECT USING (true);
CREATE POLICY "coup_ins" ON public.coupons FOR INSERT WITH CHECK (true);
CREATE POLICY "coup_upd" ON public.coupons FOR UPDATE
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));

-- promotions
CREATE POLICY "promo_sel" ON public.promotions FOR SELECT USING (true);
CREATE POLICY "promo_ins" ON public.promotions FOR INSERT WITH CHECK (true);
CREATE POLICY "promo_upd" ON public.promotions FOR UPDATE
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));

-- customer_communications (scoped to merchant)
CREATE POLICY "cc_sel" ON public.customer_communications FOR SELECT
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
CREATE POLICY "cc_ins" ON public.customer_communications FOR INSERT WITH CHECK (true);

-- stock_history
CREATE POLICY "sh_sel" ON public.stock_history FOR SELECT
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));

-- product_views
CREATE POLICY "pv_sel" ON public.product_views FOR SELECT USING (true);
CREATE POLICY "pv_ins" ON public.product_views FOR INSERT WITH CHECK (true);

-- merchant_analytics
CREATE POLICY "ma_sel" ON public.merchant_analytics FOR SELECT
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));

-- product_categories
CREATE POLICY "pc_sel" ON public.product_categories FOR SELECT USING (true);
CREATE POLICY "pc_ins" ON public.product_categories FOR INSERT WITH CHECK (true);

-- merchant_notifications
CREATE POLICY "mn_sel" ON public.merchant_notifications FOR SELECT
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
CREATE POLICY "mn_ins" ON public.merchant_notifications FOR INSERT WITH CHECK (true);

-- products
CREATE POLICY "prods_sel" ON public.products FOR SELECT USING (true);
CREATE POLICY "prods_ins" ON public.products FOR INSERT WITH CHECK (true);

-- reviews
CREATE POLICY "rev_sel" ON public.reviews FOR SELECT USING (true);
CREATE POLICY "rev_ins" ON public.reviews FOR INSERT WITH CHECK (true);

-- price_history
CREATE POLICY "phist_sel" ON public.price_history FOR SELECT USING (true);
CREATE POLICY "phist_ins" ON public.price_history FOR INSERT WITH CHECK (true);

-- prescriptions
CREATE POLICY "prescriptions_all" ON public.prescriptions FOR ALL
  USING (user_id = auth.uid()::text OR user_email = auth.email() OR public.is_admin())
  WITH CHECK (user_id = auth.uid()::text OR user_email = auth.email() OR public.is_admin());

-- sponsored_products
CREATE POLICY "spsel" ON public.sponsored_products FOR SELECT USING (true);
CREATE POLICY "spins" ON public.sponsored_products FOR INSERT WITH CHECK (public.is_admin());
CREATE POLICY "spupd" ON public.sponsored_products FOR UPDATE USING (public.is_admin());
CREATE POLICY "spdel" ON public.sponsored_products FOR DELETE USING (public.is_admin());

-- analytics
CREATE POLICY "analytics_ins" ON public.analytics FOR INSERT WITH CHECK (true);
CREATE POLICY "analytics_sel" ON public.analytics FOR SELECT USING (public.is_admin());
CREATE POLICY "analytics_upd" ON public.analytics FOR UPDATE USING (public.is_admin());

-- ============================================================================
-- SECTION 10: STORAGE BUCKETS
-- ============================================================================

INSERT INTO storage.buckets (id, name, public) VALUES ('media', 'media', true) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('products', 'products', true) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('misc', 'misc', true) ON CONFLICT (id) DO NOTHING;

-- Media bucket policies
DO $$ BEGIN
  DROP POLICY IF EXISTS "media_public_read" ON storage.objects;
  CREATE POLICY "media_public_read" ON storage.objects FOR SELECT
    USING (bucket_id = 'media');
  DROP POLICY IF EXISTS "media_auth_upload" ON storage.objects;
  CREATE POLICY "media_auth_upload" ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'media' AND (SELECT auth.uid()) IS NOT NULL);
  DROP POLICY IF EXISTS "media_auth_update" ON storage.objects;
  CREATE POLICY "media_auth_update" ON storage.objects FOR UPDATE
    USING (bucket_id = 'media' AND (SELECT auth.uid()) IS NOT NULL);
  DROP POLICY IF EXISTS "media_auth_delete" ON storage.objects;
  CREATE POLICY "media_auth_delete" ON storage.objects FOR DELETE
    USING (bucket_id = 'media');
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- Products bucket policies
DO $$ BEGIN
  DROP POLICY IF EXISTS "products_public_read" ON storage.objects;
  CREATE POLICY "products_public_read" ON storage.objects FOR SELECT
    USING (bucket_id = 'products');
  DROP POLICY IF EXISTS "products_auth_upload" ON storage.objects;
  CREATE POLICY "products_auth_upload" ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'products' AND (SELECT auth.uid()) IS NOT NULL);
  DROP POLICY IF EXISTS "products_auth_update" ON storage.objects;
  CREATE POLICY "products_auth_update" ON storage.objects FOR UPDATE
    USING (bucket_id = 'products' AND (SELECT auth.uid()) IS NOT NULL);
  DROP POLICY IF EXISTS "products_auth_delete" ON storage.objects;
  CREATE POLICY "products_auth_delete" ON storage.objects FOR DELETE
    USING (bucket_id = 'products');
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- Misc bucket policies
DO $$ BEGIN
  DROP POLICY IF EXISTS "misc_public_read" ON storage.objects;
  CREATE POLICY "misc_public_read" ON storage.objects FOR SELECT
    USING (bucket_id = 'misc');
  DROP POLICY IF EXISTS "misc_auth_upload" ON storage.objects;
  CREATE POLICY "misc_auth_upload" ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'misc' AND (SELECT auth.uid()) IS NOT NULL);
  DROP POLICY IF EXISTS "misc_auth_update" ON storage.objects;
  CREATE POLICY "misc_auth_update" ON storage.objects FOR UPDATE
    USING (bucket_id = 'misc' AND (SELECT auth.uid()) IS NOT NULL);
  DROP POLICY IF EXISTS "misc_auth_delete" ON storage.objects;
  CREATE POLICY "misc_auth_delete" ON storage.objects FOR DELETE
    USING (bucket_id = 'misc');
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- ============================================================================
-- SECTION 11: REALTIME PUBLICATIONS
-- ============================================================================

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE orders;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE medicines;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE riders;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE rider_notifications;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE merchant_kyc;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE admin_kyc_verifications;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE sponsored_products;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE delivery_requests;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE merchant_notifications;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE merchant_alerts;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE returns;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- ============================================================================
-- SECTION 12: DEMO DATA (only insert if empty)
-- ============================================================================

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM public.sponsored_products LIMIT 1) THEN
        INSERT INTO public.sponsored_products (title, subtitle, tag, gradient, icon_class, btn_text, btn_action, sort_order, is_active)
        VALUES
            ('Medicine Essentials', 'Up to 40% off on daily health needs', 'HOT DEAL', 'linear-gradient(135deg, #e02020, #ff6b6b)', 'fas fa-pills', 'Shop Now', '#', 1, true),
            ('Wellness Store', 'Premium supplements & vitamins', 'NEW ARRIVAL', 'linear-gradient(135deg, #b71c1c, #e57373)', 'fas fa-heartbeat', 'Explore', '#', 2, true),
            ('Baby Care', 'Trusted brands for your little one', 'TRENDING', 'linear-gradient(135deg, #e02020, #ff8a65)', 'fas fa-baby', 'View All', '#', 3, true),
            ('Skin Care', 'Derma recommended products', 'BESTSELLER', 'linear-gradient(135deg, #c62828, #ef5350)', 'fas fa-hand-holding-medical', 'Shop Now', '#', 4, true),
            ('Fitness & Nutrition', 'Protein, vitamins & more', 'TOP RATED', 'linear-gradient(135deg, #d32f2f, #ff5252)', 'fas fa-dumbbell', 'Browse', '#', 5, true),
            ('Monsoon Health', 'Stay safe this rainy season', 'SEASONAL', 'linear-gradient(135deg, #b71c1c, #e57373)', 'fas fa-cloud-rain', 'Shop Now', '#', 6, true);
    END IF;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- ============================================================================
-- SECTION 13: TEST SEED DATA (insert once, skip if exists)
-- ============================================================================

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM public.merchants WHERE id = 999) THEN
        INSERT INTO merchants (id, shop_name, merchant_name, email, phone, city, address, status, latitude, longitude)
        VALUES (999, 'Test Medical Store', 'Test Owner', 'test@medifinder.com', '9999999999', 'Kolkata', '123 Test Street, Kolkata - 700001', 'approved', 22.5726, 88.3639);
    END IF;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM public.medicines WHERE merchant_id = 999 LIMIT 1) THEN
        INSERT INTO medicines (merchant_id, product_name, name, composition, manufacturer, unit_price, selling_price, mrp, stock_qty, status, category, description, rating, is_rx, image_url)
        VALUES
        (999, 'Paracetamol 500mg', 'Paracetamol 500mg Strip', 'Paracetamol IP 500mg', 'Cipla Ltd', 30, 28, 35, 50, 'Approved', 'Tablet', 'Effective relief from fever and body pain', 4.5, false, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400'),
        (999, 'Amoxicillin 250mg', 'Amoxicillin 250mg Capsule', 'Amoxicillin Trihydrate 250mg', 'Sun Pharma', 85, 78, 95, 30, 'Approved', 'Capsule', 'Antibiotic for bacterial infections', 4.3, true, 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400'),
        (999, 'Cetirizine 10mg', 'Cetirizine 10mg Tablet', 'Cetirizine HCl IP 10mg', 'Zydus Cadila', 45, 40, 55, 100, 'Approved', 'Tablet', 'Antihistamine for allergies and cold', 4.6, false, 'https://images.unsplash.com/photo-1550572017-edd951b55104?w=400'),
        (999, 'Pantoprazole 40mg', 'Pantoprazole 40mg Tablet', 'Pantoprazole Sodium 40mg', 'Alkem Labs', 120, 105, 140, 25, 'Approved', 'Tablet', 'Reduces stomach acid, treats acidity and ulcers', 4.4, false, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400'),
        (999, 'Azithromycin 500mg', 'Azithromycin 500mg Tablet', 'Azithromycin Dihydrate IP 500mg', 'Zydus Cadila', 95, 88, 110, 40, 'Approved', 'Tablet', 'Macrolide antibiotic for respiratory infections', 4.2, true, 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400');
    END IF;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================
