-- ═══════════════════════════════════════════════════════════════════════════════
-- FIX_ADMIN_A_TO_Z.sql — All SQL fixes needed for Admin Panel A-to-Z
-- Run this in Supabase SQL Editor (just copy-paste and run)
-- ═══════════════════════════════════════════════════════════════════════════════

-- ============================================================
-- 1. FIX is_admin() — use exact phone match (not LIKE)
-- ============================================================
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT
    coalesce(auth.email(), '') = 'medifinderindia@gmail.com'
    OR coalesce(auth.jwt() ->> 'phone', '') = '+919593625498'
    OR coalesce(auth.jwt() ->> 'email', auth.email(), '') = 'medifinderindia@gmail.com'
$$;

-- ============================================================
-- 2. ADD medicines DELETE policy (needed by removeMedicineByModal)
-- ============================================================
DROP POLICY IF EXISTS "meds_del" ON public.medicines;
CREATE POLICY "meds_del" ON public.medicines FOR DELETE
  USING (public.is_admin());

-- ============================================================
-- 3. ADD merchant_payouts INSERT policy (needed if any INSERT happens)
-- ============================================================
DROP POLICY IF EXISTS "mpay_ins" ON public.merchant_payouts;
CREATE POLICY "mpay_ins" ON public.merchant_payouts FOR INSERT
  WITH CHECK (public.is_admin());

-- ============================================================
-- 4. ADD DELETE policy for rx_orders (admin cleanup)
-- ============================================================
DROP POLICY IF EXISTS "rx_del" ON public.rx_orders;
CREATE POLICY "rx_del" ON public.rx_orders FOR DELETE
  USING (public.is_admin());

-- ============================================================
-- 5. ADD DELETE policy for order_items (admin cleanup)
-- ============================================================
DROP POLICY IF EXISTS "oi_del" ON public.order_items;
CREATE POLICY "oi_del" ON public.order_items FOR DELETE
  USING (public.is_admin());

-- ============================================================
-- 6. ADD UPDATE policy for returns (admin processes refunds)
-- ============================================================
DROP POLICY IF EXISTS "ret_upd" ON public.returns;
CREATE POLICY "ret_upd" ON public.returns FOR UPDATE
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- ============================================================
-- 7. ADD UPDATE policy for admin_payout_requests
-- ============================================================
DROP POLICY IF EXISTS "apr_upd" ON public.admin_payout_requests;
CREATE POLICY "apr_upd" ON public.admin_payout_requests FOR UPDATE
  USING (public.is_admin());

-- ============================================================
-- 8. ADD DELETE policies for admin on key tables
-- ============================================================
DROP POLICY IF EXISTS "merchants_del" ON public.merchants;
CREATE POLICY "merchants_del" ON public.merchants FOR DELETE
  USING (public.is_admin());

DROP POLICY IF EXISTS "riders_del" ON public.riders;
CREATE POLICY "riders_del" ON public.riders FOR DELETE
  USING (public.is_admin());

DROP POLICY IF EXISTS "profiles_del" ON public.profiles;
CREATE POLICY "profiles_del" ON public.profiles FOR DELETE
  USING (public.is_admin());

DROP POLICY IF EXISTS "coup_del" ON public.coupons;
CREATE POLICY "coup_del" ON public.coupons FOR DELETE
  USING (public.is_admin());

DROP POLICY IF EXISTS "promo_del" ON public.promotions;
CREATE POLICY "promo_del" ON public.promotions FOR DELETE
  USING (public.is_admin());

-- ============================================================
-- 9. ADD UPDATE policy for checkups (admin manages health records)
-- ============================================================
DROP POLICY IF EXISTS "checkups_upd" ON public.checkups;
CREATE POLICY "checkups_upd" ON public.checkups FOR UPDATE
  USING (public.is_admin());

-- ============================================================
-- 10-15. ADD realtime publications (skip if already member)
-- Each wrapped in DO block to avoid "already member" error (42710)
-- ============================================================
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE payout_history; EXCEPTION WHEN OTHERS THEN IF SQLSTATE = '42710' THEN NULL; ELSE RAISE; END IF; END; $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE service_zones; EXCEPTION WHEN OTHERS THEN IF SQLSTATE = '42710' THEN NULL; ELSE RAISE; END IF; END; $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE rider_payouts; EXCEPTION WHEN OTHERS THEN IF SQLSTATE = '42710' THEN NULL; ELSE RAISE; END IF; END; $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE merchant_payouts; EXCEPTION WHEN OTHERS THEN IF SQLSTATE = '42710' THEN NULL; ELSE RAISE; END IF; END; $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE rider_kyc; EXCEPTION WHEN OTHERS THEN IF SQLSTATE = '42710' THEN NULL; ELSE RAISE; END IF; END; $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE cancelled_orders; EXCEPTION WHEN OTHERS THEN IF SQLSTATE = '42710' THEN NULL; ELSE RAISE; END IF; END; $$;

-- ============================================================
-- 16. ADD missing columns to merchant_kyc (created_at, verified_at, rejected_at)
-- ============================================================
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ;

-- ============================================================
-- 17. ADD missing columns to rider_kyc (just in case)
-- ============================================================
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ;

-- ═══════════════════════════════════════════════════════════════════════════════
-- ✅ DONE — Run this once in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════════════════════════
