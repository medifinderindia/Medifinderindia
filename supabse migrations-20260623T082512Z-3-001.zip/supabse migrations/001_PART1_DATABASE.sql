﻿-- ============================================================================
-- MEDIFINDER PART 1 — Sections 0-4 (Cleanup, Functions, Tables)
-- ============================================================================
-- SAFE TO RUN MULTIPLE TIMES
-- ============================================================================
-- SECTION 0: CLEANUP â€” drop broken triggers/functions that cause errors
-- ============================================================================
DROP TRIGGER IF EXISTS trg_bridge_rider_kyc ON public.admin_kyc_verifications CASCADE;
DROP FUNCTION IF EXISTS public.bridge_rider_kyc_submission() CASCADE;
DROP FUNCTION IF EXISTS public.handle_new_merchant_mapping_fallback() CASCADE;

-- ============================================================================
-- SECTION 1: FUNCTIONS
-- ============================================================================

-- is_admin() â€” checks email and phone
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT
    coalesce(auth.email(), '') = 'medifinderindia@gmail.com'
    OR coalesce(auth.jwt() ->> 'phone', '') LIKE '%9593625498'
    OR coalesce(auth.jwt() ->> 'email', auth.email(), '') = 'medifinderindia@gmail.com'
$$;

-- updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- SECTION 2: CORE TABLES (CREATE TABLE IF NOT EXISTS)
-- ============================================================================

-- profiles
CREATE TABLE IF NOT EXISTS profiles (
    id TEXT PRIMARY KEY DEFAULT '',
    email TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    full_name TEXT DEFAULT '',
    role TEXT DEFAULT 'user',
    address TEXT DEFAULT '',
    city TEXT DEFAULT '',
    state TEXT DEFAULT '',
    pincode TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- patients
CREATE TABLE IF NOT EXISTS patients (
    id TEXT PRIMARY KEY DEFAULT '',
    user_id TEXT,
    user_email TEXT DEFAULT '',
    name TEXT NOT NULL DEFAULT '',
    age TEXT DEFAULT '',
    gender TEXT DEFAULT '',
    relationship TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- reminders
CREATE TABLE IF NOT EXISTS reminders (
    id TEXT PRIMARY KEY DEFAULT '',
    user_id TEXT,
    user_email TEXT DEFAULT '',
    patient_id TEXT,
    medicine_name TEXT NOT NULL DEFAULT '',
    medicine TEXT DEFAULT '',
    dosage TEXT DEFAULT '',
    frequency TEXT DEFAULT '',
    times TEXT[],
    time TEXT DEFAULT '',
    is_active BOOLEAN DEFAULT true,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- merchants
CREATE TABLE IF NOT EXISTS merchants (
    id BIGSERIAL PRIMARY KEY,
    auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    user_id UUID,
    email TEXT DEFAULT '',
    merchant_name TEXT DEFAULT '',
    shop_name TEXT DEFAULT '',
    owner_name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    merchant_avatar TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    license_status TEXT DEFAULT 'Unverified',
    license_id TEXT DEFAULT '',
    license_img TEXT DEFAULT '',
    bank_no TEXT DEFAULT '',
    ifsc_code TEXT DEFAULT '',
    upi_id TEXT DEFAULT '',
    bank_image TEXT DEFAULT '',
    pincode TEXT DEFAULT '',
    city TEXT DEFAULT '',
    district TEXT DEFAULT '',
    state TEXT DEFAULT '',
    address TEXT DEFAULT '',
    resolved_address TEXT DEFAULT '',
    latitude NUMERIC DEFAULT 22.5726,
    longitude NUMERIC DEFAULT 88.3639,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- medicines
CREATE TABLE IF NOT EXISTS medicines (
    id BIGSERIAL PRIMARY KEY,
    merchant_id BIGINT,
    shop_id TEXT,
    product_name TEXT NOT NULL DEFAULT '',
    name TEXT DEFAULT '',
    composition TEXT DEFAULT '',
    dosage_form TEXT DEFAULT '',
    dosage TEXT DEFAULT '',
    strength TEXT DEFAULT '',
    manufacturer TEXT DEFAULT '',
    prescription_req TEXT DEFAULT 'No',
    mfd_date DATE,
    expiry_date DATE,
    batch_number TEXT DEFAULT '',
    storage_condition TEXT DEFAULT '',
    unit_price NUMERIC DEFAULT 0,
    selling_price NUMERIC,
    mrp NUMERIC,
    drug_type TEXT DEFAULT '',
    stock_qty INTEGER DEFAULT 0,
    unit_type TEXT DEFAULT 'Strip',
    rack_location TEXT DEFAULT '',
    side_effects TEXT DEFAULT '',
    status TEXT DEFAULT 'Pending',
    admin_approved BOOLEAN DEFAULT false,
    image_url TEXT DEFAULT '',
    category TEXT DEFAULT 'Medicine',
    description TEXT DEFAULT '',
    rating NUMERIC DEFAULT 4.5,
    is_rx BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- prescriptions
CREATE TABLE IF NOT EXISTS prescriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT,
    user_email TEXT DEFAULT '',
    image_url TEXT DEFAULT '',
    status TEXT DEFAULT 'pending',
    notes TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- riders
CREATE TABLE IF NOT EXISTS riders (
    id BIGSERIAL PRIMARY KEY,
    auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT DEFAULT '',
    full_name TEXT DEFAULT '',
    name TEXT DEFAULT '',
    username TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    status TEXT DEFAULT 'offline',
    duty_status TEXT DEFAULT 'offline',
    vehicle_type TEXT DEFAULT 'bike',
    vehicle_plate TEXT DEFAULT '',
    vehicle_number TEXT DEFAULT '',
    license_number TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    ifsc_code TEXT DEFAULT '',
    upi_id TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    is_verified BOOLEAN DEFAULT false,
    latitude NUMERIC DEFAULT 22.5726,
    longitude NUMERIC DEFAULT 88.3639,
    current_lat NUMERIC,
    current_lon NUMERIC,
    current_order_id UUID,
    rating NUMERIC DEFAULT 4.5,
    total_deliveries INTEGER DEFAULT 0,
    has_active_order BOOLEAN DEFAULT false,
    is_on_route BOOLEAN DEFAULT false,
    location_updated_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- orders
CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    user_id TEXT,
    user_email TEXT DEFAULT '',
    merchant_id BIGINT,
    rider_id BIGINT,
    customer_id UUID,
    customer_name TEXT DEFAULT '',
    customer_phone TEXT DEFAULT '',
    customer_address TEXT DEFAULT '',
    customer_email TEXT DEFAULT '',
    items JSONB DEFAULT '[]',
    items_text TEXT DEFAULT '',
    items_img TEXT DEFAULT '',
    address TEXT DEFAULT '',
    delivery_address TEXT DEFAULT '',
    payment_mode TEXT DEFAULT 'cod',
    payment_method TEXT DEFAULT 'cod',
    total_bill TEXT DEFAULT '',
    total_amount NUMERIC DEFAULT 0,
    total NUMERIC DEFAULT 0,
    final_amount NUMERIC DEFAULT 0,
    delivery_fee NUMERIC DEFAULT 0,
    delivery_charge NUMERIC DEFAULT 45,
    tax NUMERIC DEFAULT 0,
    discount NUMERIC DEFAULT 0,
    payment_status TEXT DEFAULT 'Pending',
    status TEXT DEFAULT 'pending',
    rx_verified BOOLEAN DEFAULT false,
    transit_mode TEXT DEFAULT '',
    vehicle_type TEXT DEFAULT '',
    eta_minutes INTEGER DEFAULT 30,
    shop_lat NUMERIC,
    shop_lng NUMERIC,
    pharmacy_lat NUMERIC,
    pharmacy_lon NUMERIC,
    pharmacy_name TEXT DEFAULT '',
    user_lat NUMERIC,
    user_lon NUMERIC,
    user_name TEXT DEFAULT '',
    user_phone TEXT DEFAULT '',
    rider_lat NUMERIC,
    rider_lon NUMERIC,
    location_updated_at TIMESTAMPTZ,
    delivery_secure_code TEXT DEFAULT '',
    customer_otp TEXT DEFAULT '',
    date_string TEXT DEFAULT '',
    cancellation_reason TEXT DEFAULT '',
    cancellation_note TEXT DEFAULT '',
    prescription_url TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    delivery_lat NUMERIC,
    delivery_lng NUMERIC,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- cancelled_orders
CREATE TABLE IF NOT EXISTS cancelled_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    customer TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    reason TEXT DEFAULT '',
    payment TEXT DEFAULT '',
    status TEXT DEFAULT 'Pending',
    cancelled_by TEXT DEFAULT '',
    refund_amount NUMERIC DEFAULT 0,
    refunded_at TIMESTAMPTZ,
    user_email TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- rx_orders
CREATE TABLE IF NOT EXISTS rx_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    user_id TEXT,
    prescription_url TEXT NOT NULL DEFAULT '',
    verified BOOLEAN DEFAULT false,
    verified_by TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    rx_status TEXT DEFAULT 'pending',
    rx_image TEXT DEFAULT '',
    medicine_name TEXT DEFAULT '',
    customer_name TEXT DEFAULT '',
    customer_phone TEXT DEFAULT '',
    doctor_name TEXT DEFAULT '',
    hospital_name TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    approved_at TIMESTAMPTZ,
    approved_by TEXT DEFAULT '',
    rejected_at TIMESTAMPTZ,
    rejection_reason TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- rider_kyc
CREATE TABLE IF NOT EXISTS rider_kyc (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    name TEXT DEFAULT '',
    license_no TEXT DEFAULT '',
    plate_no TEXT DEFAULT '',
    license_img TEXT DEFAULT '',
    plate_img TEXT DEFAULT '',
    aadhaar_number TEXT DEFAULT '',
    aadhaar_img TEXT DEFAULT '',
    pan_number TEXT DEFAULT '',
    pan_img TEXT DEFAULT '',
    vehicle_rc TEXT DEFAULT '',
    vehicle_img TEXT DEFAULT '',
    insurance_img TEXT DEFAULT '',
    verified BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- rider_payouts
CREATE TABLE IF NOT EXISTS rider_payouts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    name TEXT DEFAULT '',
    contact TEXT DEFAULT '',
    hours TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    destination TEXT DEFAULT '',
    paid BOOLEAN DEFAULT false,
    status TEXT DEFAULT 'pending',
    upi_id TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    ifsc TEXT DEFAULT '',
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- admin_kyc_verifications
CREATE TABLE IF NOT EXISTS admin_kyc_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    merchant_id BIGINT,
    kyc_type TEXT DEFAULT '',
    data_payload JSONB DEFAULT '{}',
    status TEXT DEFAULT 'pending',
    submitted_at TIMESTAMPTZ DEFAULT NOW(),
    verified_at TIMESTAMPTZ,
    admin_notes TEXT DEFAULT ''
);

-- admin_payout_requests
CREATE TABLE IF NOT EXISTS admin_payout_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT,
    entity_type TEXT DEFAULT '',
    entity_id UUID,
    total_payout_amount NUMERIC DEFAULT 0,
    active_duty_hours NUMERIC DEFAULT 0,
    request_status TEXT DEFAULT 'pending',
    requested_at TIMESTAMPTZ DEFAULT NOW(),
    amount NUMERIC DEFAULT 0,
    status TEXT DEFAULT 'pending',
    upi_id TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    ifsc TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    processed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- payout_history
CREATE TABLE IF NOT EXISTS payout_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id TEXT DEFAULT '',
    recipient_name TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    entity_type TEXT DEFAULT '',
    entity_id UUID,
    type TEXT DEFAULT '',
    payment_method TEXT DEFAULT 'Bank Transfer',
    method TEXT DEFAULT '',
    status TEXT DEFAULT 'Completed',
    reference TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- riders_wallet
CREATE TABLE IF NOT EXISTS riders_wallet (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rider_id BIGINT UNIQUE,
    order_id TEXT,
    amount_earned NUMERIC DEFAULT 0,
    balance NUMERIC DEFAULT 0,
    total_earned NUMERIC DEFAULT 0,
    total_withdrawn NUMERIC DEFAULT 0,
    status TEXT DEFAULT 'success',
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- service_zones
CREATE TABLE IF NOT EXISTS service_zones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT DEFAULT '',
    pin TEXT DEFAULT '',
    dist TEXT DEFAULT '',
    ps TEXT DEFAULT '',
    muni TEXT DEFAULT '',
    state TEXT DEFAULT '',
    city TEXT DEFAULT '',
    pincode TEXT DEFAULT '',
    riders INTEGER DEFAULT 0,
    merchants INTEGER DEFAULT 0,
    users INTEGER DEFAULT 0,
    status TEXT DEFAULT 'approved',
    outage_message TEXT DEFAULT '',
    outage_start TIMESTAMPTZ,
    radius_km NUMERIC DEFAULT 10,
    center_lat NUMERIC DEFAULT 22.5726,
    center_lng NUMERIC DEFAULT 88.3639,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- offers
CREATE TABLE IF NOT EXISTS offers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    title TEXT DEFAULT '',
    description TEXT DEFAULT '',
    text TEXT DEFAULT '',
    discount_type TEXT DEFAULT 'percentage',
    discount_value NUMERIC DEFAULT 0,
    min_order NUMERIC DEFAULT 0,
    max_discount NUMERIC DEFAULT 0,
    code TEXT DEFAULT '',
    status TEXT DEFAULT 'inactive',
    active BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    expiry TEXT DEFAULT '',
    start_date TIMESTAMPTZ DEFAULT NOW(),
    end_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- checkups
CREATE TABLE IF NOT EXISTS checkups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT DEFAULT '',
    name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    topic TEXT DEFAULT '',
    type TEXT DEFAULT '',
    date DATE,
    result TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- notifications
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target TEXT DEFAULT 'all',
    user_id TEXT DEFAULT '',
    title TEXT NOT NULL DEFAULT '',
    message TEXT DEFAULT '',
    text TEXT DEFAULT '',
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- merchant_kyc
CREATE TABLE IF NOT EXISTS merchant_kyc (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    license_img TEXT DEFAULT '',
    license_no TEXT DEFAULT '',
    verified BOOLEAN DEFAULT false,
    rejection_reason TEXT DEFAULT '',
    rejected_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- merchant_alerts
CREATE TABLE IF NOT EXISTS merchant_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target_audience TEXT DEFAULT 'all',
    shop_id TEXT DEFAULT '',
    merchant_id BIGINT,
    title TEXT NOT NULL DEFAULT '',
    message TEXT DEFAULT '',
    type TEXT DEFAULT 'info',
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- merchant_payouts
CREATE TABLE IF NOT EXISTS merchant_payouts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    order_id TEXT DEFAULT '',
    shop_id TEXT DEFAULT '',
    pickup_address TEXT DEFAULT '',
    drop_address TEXT DEFAULT '',
    amount NUMERIC DEFAULT 0,
    payment_mode TEXT DEFAULT 'Online Transfer',
    status TEXT DEFAULT 'Pending',
    settled_at TIMESTAMPTZ,
    upi_id TEXT DEFAULT '',
    bank_account TEXT DEFAULT '',
    ifsc TEXT DEFAULT '',
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- rider_notifications
CREATE TABLE IF NOT EXISTS rider_notifications (
    id BIGSERIAL PRIMARY KEY,
    rider_id BIGINT REFERENCES public.riders(id) ON DELETE CASCADE,
    title TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL DEFAULT '',
    type TEXT DEFAULT 'info',
    broadcast_to TEXT DEFAULT 'individual',
    created_by TEXT DEFAULT 'admin',
    is_read BOOLEAN DEFAULT false,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- analytics
CREATE TABLE IF NOT EXISTS analytics (
    id BIGSERIAL PRIMARY KEY,
    metric_type TEXT DEFAULT '',
    metric_value NUMERIC(15,2),
    metric_date DATE,
    event_type TEXT DEFAULT '',
    entity_type TEXT DEFAULT '',
    entity_id UUID,
    data JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- SECTION 3: MERCHANT FEATURE TABLES (from 009)
-- ============================================================================

CREATE TABLE IF NOT EXISTS order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    medicine_id BIGINT,
    merchant_id BIGINT,
    product_name TEXT NOT NULL DEFAULT '',
    product_image TEXT DEFAULT '',
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10,2) DEFAULT 0,
    total_price DECIMAL(10,2) DEFAULT 0,
    discount DECIMAL(10,2) DEFAULT 0,
    tax DECIMAL(10,2) DEFAULT 0,
    batch_number TEXT DEFAULT '',
    expiry_date TEXT DEFAULT '',
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS returns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT,
    order_item_id UUID,
    merchant_id BIGINT,
    customer_id TEXT,
    reason TEXT NOT NULL DEFAULT '',
    description TEXT DEFAULT '',
    customer_photos TEXT[],
    status TEXT DEFAULT 'pending',
    refund_amount DECIMAL(10,2) DEFAULT 0,
    refund_method TEXT DEFAULT '',
    refund_status TEXT DEFAULT 'pending',
    refund_processed_at TIMESTAMPTZ,
    return_pickup_date TIMESTAMPTZ,
    return_received_date TIMESTAMPTZ,
    admin_notes TEXT DEFAULT '',
    merchant_notes TEXT DEFAULT '',
    date_requested TIMESTAMPTZ DEFAULT NOW(),
    timeline JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS coupons (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    code TEXT NOT NULL DEFAULT '',
    description TEXT DEFAULT '',
    discount_type TEXT DEFAULT 'percentage',
    discount_value DECIMAL(10,2) DEFAULT 0,
    min_order_amount DECIMAL(10,2) DEFAULT 0,
    max_discount_amount DECIMAL(10,2),
    max_uses INT DEFAULT 100,
    used_count INT DEFAULT 0,
    applicable_products UUID[],
    applicable_categories TEXT[],
    start_date TIMESTAMPTZ DEFAULT NOW(),
    end_date TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS promotions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    type TEXT DEFAULT 'discount',
    title TEXT NOT NULL DEFAULT '',
    description TEXT DEFAULT '',
    banner_image TEXT DEFAULT '',
    discount_type TEXT DEFAULT '',
    discount_value DECIMAL(10,2) DEFAULT 0,
    applicable_products UUID[],
    applicable_categories TEXT[],
    start_date TIMESTAMPTZ NOT NULL,
    end_date TIMESTAMPTZ NOT NULL,
    status TEXT DEFAULT 'active',
    budget DECIMAL(10,2) DEFAULT 0,
    spent DECIMAL(10,2) DEFAULT 0,
    impressions INT DEFAULT 0,
    clicks INT DEFAULT 0,
    conversions INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS customer_communications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    customer_id TEXT,
    order_id TEXT,
    message TEXT NOT NULL DEFAULT '',
    subject TEXT DEFAULT '',
    type TEXT DEFAULT 'order_update',
    channel TEXT DEFAULT 'in_app',
    is_read BOOLEAN DEFAULT false,
    sent_by TEXT DEFAULT 'merchant',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS stock_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    medicine_id BIGINT,
    merchant_id BIGINT,
    change_type TEXT NOT NULL DEFAULT '',
    quantity_change INT DEFAULT 0,
    previous_stock INT DEFAULT 0,
    new_stock INT DEFAULT 0,
    reason TEXT DEFAULT '',
    batch_number TEXT DEFAULT '',
    performed_by TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS product_views (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    medicine_id BIGINT,
    merchant_id BIGINT,
    viewer_id TEXT,
    viewer_ip TEXT,
    viewer_device TEXT,
    source TEXT DEFAULT 'direct',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS merchant_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    date DATE DEFAULT CURRENT_DATE,
    total_orders INT DEFAULT 0,
    total_revenue DECIMAL(10,2) DEFAULT 0,
    total_items_sold INT DEFAULT 0,
    new_customers INT DEFAULT 0,
    returning_customers INT DEFAULT 0,
    returns_count INT DEFAULT 0,
    refunds_amount DECIMAL(10,2) DEFAULT 0,
    avg_order_value DECIMAL(10,2) DEFAULT 0,
    conversion_rate DECIMAL(5,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(merchant_id, date)
);

CREATE TABLE IF NOT EXISTS product_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    name TEXT NOT NULL DEFAULT '',
    description TEXT DEFAULT '',
    icon TEXT DEFAULT '',
    is_active BOOLEAN DEFAULT true,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS merchant_notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    title TEXT NOT NULL DEFAULT '',
    message TEXT DEFAULT '',
    type TEXT DEFAULT 'info',
    category TEXT DEFAULT 'general',
    reference_id UUID,
    reference_type TEXT DEFAULT '',
    is_read BOOLEAN DEFAULT false,
    action_url TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- SECTION 4: ADDITIONAL TABLES (from 011)
-- ============================================================================

CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id BIGINT,
    name TEXT NOT NULL DEFAULT '',
    price DECIMAL(10,2) DEFAULT 0,
    mrp DECIMAL(10,2) DEFAULT 0,
    category TEXT DEFAULT '',
    stock INT DEFAULT 0,
    image_url TEXT DEFAULT '',
    description TEXT DEFAULT '',
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID,
    user_id TEXT DEFAULT '',
    rating INT DEFAULT 5,
    review_text TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS price_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID,
    merchant_id BIGINT,
    new_price DECIMAL(10,2) DEFAULT 0,
    old_price DECIMAL(10,2) DEFAULT 0,
    change_type TEXT DEFAULT '',
    change_value DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================

