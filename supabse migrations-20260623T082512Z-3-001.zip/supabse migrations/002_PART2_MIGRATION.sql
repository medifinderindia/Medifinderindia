﻿-- SECTION 5: PARTNER_MEDICINES VIEW (auto-syncs from medicines+merchants)
-- ============================================================================

DO $$ BEGIN

-- Drop if old TABLE exists from a previous migration
DROP VIEW IF EXISTS partner_medicines;

-- Create as VIEW â€” auto-reflects approved medicines
CREATE OR REPLACE VIEW public.partner_medicines AS
SELECT
  m.id, m.name, m.category, m.unit_price AS price,
  m.image_url, m.image_url AS img,
  m.expiry_date::text AS expiry, m.rating,
  mc.merchant_name AS manufacturer, m.description,
  (m.prescription_req = 'Yes') AS is_rx,
  (m.status IN ('Approved','Active') AND m.stock_qty > 0 AND coalesce(m.admin_approved, false)) AS approved,
  m.merchant_id, m.stock_qty, m.created_at
FROM public.medicines m
JOIN public.merchants mc ON mc.id = m.merchant_id;

EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
-- SECTION 6: ADD COLUMN IF NOT EXISTS (all extra columns on existing tables)
-- ============================================================================

DO $$ BEGIN

-- admin_kyc_verifications
ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS rider_id BIGINT;
ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS kyc_type TEXT;
ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS data_payload JSONB;
ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS submitted_at TIMESTAMPTZ DEFAULT now();
ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;
ALTER TABLE public.admin_kyc_verifications ADD COLUMN IF NOT EXISTS admin_notes TEXT;

-- profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS full_name TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'user';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS address TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS city TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS state TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS pincode TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_url TEXT DEFAULT '';

-- patients
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS user_id TEXT;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS user_email TEXT DEFAULT '';
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS name TEXT DEFAULT '';
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS age TEXT DEFAULT '';
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS gender TEXT DEFAULT '';
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS relationship TEXT DEFAULT '';
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS phone TEXT DEFAULT '';

-- reminders
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS user_id TEXT;
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS user_email TEXT DEFAULT '';
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS patient_id TEXT;
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS medicine_name TEXT DEFAULT '';
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS medicine TEXT DEFAULT '';
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS dosage TEXT DEFAULT '';
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS frequency TEXT DEFAULT '';
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS times TEXT[];
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS time TEXT DEFAULT '';
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE public.reminders ADD COLUMN IF NOT EXISTS active BOOLEAN DEFAULT true;

-- merchants
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS auth_user_id UUID;
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS user_id UUID;
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS email TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS merchant_name TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS shop_name TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS owner_name TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS phone TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS merchant_avatar TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS avatar_url TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS license_status TEXT DEFAULT 'Unverified';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS license_id TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS license_img TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS bank_no TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS ifsc_code TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS upi_id TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS bank_image TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS pincode TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS city TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS district TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS state TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS address TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS resolved_address TEXT DEFAULT '';
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS latitude NUMERIC DEFAULT 22.5726;
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS longitude NUMERIC DEFAULT 88.3639;
ALTER TABLE public.merchants ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';

-- medicines
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS shop_id TEXT;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS product_name TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS name TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS composition TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS dosage_form TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS dosage TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS strength TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS manufacturer TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS prescription_req TEXT DEFAULT 'No';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS mfd_date DATE;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS expiry_date DATE;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS batch_number TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS storage_condition TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS unit_price NUMERIC DEFAULT 0;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS selling_price NUMERIC;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS mrp NUMERIC;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS drug_type TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS stock_qty INTEGER DEFAULT 0;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS unit_type TEXT DEFAULT 'Strip';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS rack_location TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS side_effects TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Pending';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS admin_approved BOOLEAN DEFAULT false;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS image_url TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'Medicine';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS description TEXT DEFAULT '';
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS rating NUMERIC DEFAULT 4.5;
ALTER TABLE public.medicines ADD COLUMN IF NOT EXISTS is_rx BOOLEAN DEFAULT false;

-- riders
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS auth_user_id UUID;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS email TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS full_name TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS name TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS username TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS phone TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'offline';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS duty_status TEXT DEFAULT 'offline';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS vehicle_type TEXT DEFAULT 'bike';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS vehicle_plate TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS vehicle_number TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS license_number TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS bank_account TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS ifsc_code TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS upi_id TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS avatar_url TEXT DEFAULT '';
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT false;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS latitude NUMERIC DEFAULT 22.5726;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS longitude NUMERIC DEFAULT 88.3639;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS current_lat NUMERIC;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS current_lon NUMERIC;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS current_order_id UUID;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS rating NUMERIC DEFAULT 4.5;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS total_deliveries INTEGER DEFAULT 0;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS has_active_order BOOLEAN DEFAULT false;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS is_on_route BOOLEAN DEFAULT false;
ALTER TABLE public.riders ADD COLUMN IF NOT EXISTS location_updated_at TIMESTAMPTZ;

-- orders
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS order_id TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_id TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_email TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rider_id BIGINT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_id UUID;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_name TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_phone TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_address TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_email TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items JSONB DEFAULT '[]';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items_text TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS items_img TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS address TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_address TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_mode TEXT DEFAULT 'cod';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_method TEXT DEFAULT 'cod';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total_bill TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total_amount NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS total NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS final_amount NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_fee NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_charge NUMERIC DEFAULT 45;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tax NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS discount NUMERIC DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'Pending';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rx_verified BOOLEAN DEFAULT false;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS transit_mode TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS vehicle_type TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS eta_minutes INTEGER DEFAULT 30;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS shop_lat NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS shop_lng NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS pharmacy_lat NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS pharmacy_lon NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS pharmacy_name TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_lat NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_lon NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_name TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS user_phone TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rider_lat NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rider_lon NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS location_updated_at TIMESTAMPTZ;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_secure_code TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_otp TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS date_string TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancellation_reason TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancellation_note TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS prescription_url TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT '';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_lat NUMERIC;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_lng NUMERIC;

-- rx_orders
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS order_id TEXT;
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS user_id TEXT;
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS prescription_url TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS verified BOOLEAN DEFAULT false;
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS verified_by TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS rx_status TEXT DEFAULT 'pending';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS rx_image TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS medicine_name TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS customer_name TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS customer_phone TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS doctor_name TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS hospital_name TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS amount NUMERIC DEFAULT 0;
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ;
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS approved_by TEXT DEFAULT '';
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ;
ALTER TABLE public.rx_orders ADD COLUMN IF NOT EXISTS rejection_reason TEXT DEFAULT '';

-- cancelled_orders
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS order_id TEXT;
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS customer TEXT DEFAULT '';
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS amount NUMERIC DEFAULT 0;
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS reason TEXT DEFAULT '';
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS payment TEXT DEFAULT '';
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Pending';
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS cancelled_by TEXT DEFAULT '';
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS refund_amount NUMERIC DEFAULT 0;
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS refunded_at TIMESTAMPTZ;
ALTER TABLE public.cancelled_orders ADD COLUMN IF NOT EXISTS user_email TEXT DEFAULT '';

-- order_items
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS order_id TEXT;
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS medicine_id BIGINT;
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS product_name TEXT DEFAULT '';
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS name TEXT DEFAULT '';
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS quantity INTEGER DEFAULT 1;
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS price NUMERIC DEFAULT 0;
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS mrp NUMERIC DEFAULT 0;
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS image_url TEXT DEFAULT '';
ALTER TABLE public.order_items ADD COLUMN IF NOT EXISTS total NUMERIC DEFAULT 0;

-- notifications
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS user_id TEXT DEFAULT '';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS title TEXT DEFAULT '';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS message TEXT DEFAULT '';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS text TEXT DEFAULT '';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS target TEXT DEFAULT 'all';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS is_read BOOLEAN DEFAULT false;

-- offers
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS title TEXT DEFAULT '';
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS description TEXT DEFAULT '';
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS text TEXT DEFAULT '';
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS discount_type TEXT DEFAULT 'percentage';
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS discount_value NUMERIC DEFAULT 0;
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS min_order NUMERIC DEFAULT 0;
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS max_discount NUMERIC DEFAULT 0;
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS code TEXT DEFAULT '';
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'inactive';
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS active BOOLEAN DEFAULT false;
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS expiry TEXT DEFAULT '';
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS start_date TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE public.offers ADD COLUMN IF NOT EXISTS end_date TIMESTAMPTZ;

-- checkups
ALTER TABLE public.checkups ADD COLUMN IF NOT EXISTS user_id TEXT DEFAULT '';
ALTER TABLE public.checkups ADD COLUMN IF NOT EXISTS name TEXT DEFAULT '';
ALTER TABLE public.checkups ADD COLUMN IF NOT EXISTS phone TEXT DEFAULT '';
ALTER TABLE public.checkups ADD COLUMN IF NOT EXISTS topic TEXT DEFAULT '';
ALTER TABLE public.checkups ADD COLUMN IF NOT EXISTS type TEXT DEFAULT '';
ALTER TABLE public.checkups ADD COLUMN IF NOT EXISTS date DATE;
ALTER TABLE public.checkups ADD COLUMN IF NOT EXISTS result TEXT DEFAULT '';
ALTER TABLE public.checkups ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT '';

-- merchant_kyc
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS license_img TEXT DEFAULT '';
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS license_no TEXT DEFAULT '';
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS verified BOOLEAN DEFAULT false;
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS rejection_reason TEXT DEFAULT '';
ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ;

-- merchant_alerts
ALTER TABLE public.merchant_alerts ADD COLUMN IF NOT EXISTS target_audience TEXT DEFAULT 'all';
ALTER TABLE public.merchant_alerts ADD COLUMN IF NOT EXISTS shop_id TEXT DEFAULT '';
ALTER TABLE public.merchant_alerts ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.merchant_alerts ADD COLUMN IF NOT EXISTS title TEXT DEFAULT '';
ALTER TABLE public.merchant_alerts ADD COLUMN IF NOT EXISTS message TEXT DEFAULT '';
ALTER TABLE public.merchant_alerts ADD COLUMN IF NOT EXISTS type TEXT DEFAULT 'info';
ALTER TABLE public.merchant_alerts ADD COLUMN IF NOT EXISTS is_read BOOLEAN DEFAULT false;

-- merchant_payouts
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS order_id TEXT DEFAULT '';
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS shop_id TEXT DEFAULT '';
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS pickup_address TEXT DEFAULT '';
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS drop_address TEXT DEFAULT '';
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS amount NUMERIC DEFAULT 0;
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS payment_mode TEXT DEFAULT 'Online Transfer';
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Pending';
ALTER TABLE public.merchant_payouts ADD COLUMN IF NOT EXISTS settled_at TIMESTAMPTZ;

-- returns
ALTER TABLE public.returns ADD COLUMN IF NOT EXISTS order_id TEXT;
ALTER TABLE public.returns ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.returns ADD COLUMN IF NOT EXISTS medicine_name TEXT DEFAULT '';
ALTER TABLE public.returns ADD COLUMN IF NOT EXISTS quantity INTEGER DEFAULT 1;
ALTER TABLE public.returns ADD COLUMN IF NOT EXISTS reason TEXT DEFAULT '';
ALTER TABLE public.returns ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Pending';
ALTER TABLE public.returns ADD COLUMN IF NOT EXISTS refund_amount NUMERIC DEFAULT 0;

-- coupons
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS code TEXT DEFAULT '';
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS discount NUMERIC DEFAULT 0;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS discount_type TEXT DEFAULT 'percentage';
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS min_order NUMERIC DEFAULT 0;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS max_discount NUMERIC DEFAULT 0;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS usage_limit INTEGER DEFAULT 0;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS used_count INTEGER DEFAULT 0;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE public.coupons ADD COLUMN IF NOT EXISTS expiry TIMESTAMPTZ;

-- promotions
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS title TEXT DEFAULT '';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS description TEXT DEFAULT '';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS discount_percent NUMERIC DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

-- stock_history
ALTER TABLE public.stock_history ADD COLUMN IF NOT EXISTS medicine_id BIGINT;
ALTER TABLE public.stock_history ADD COLUMN IF NOT EXISTS merchant_id BIGINT;
ALTER TABLE public.stock_history ADD COLUMN IF NOT EXISTS change_qty INTEGER DEFAULT 0;
ALTER TABLE public.stock_history ADD COLUMN IF NOT EXISTS reason TEXT DEFAULT '';

-- product_views
ALTER TABLE public.product_views ADD COLUMN IF NOT EXISTS medicine_id BIGINT;
ALTER TABLE public.product_views ADD COLUMN IF NOT EXISTS viewer_id TEXT DEFAULT '';
ALTER TABLE public.product_views ADD COLUMN IF NOT EXISTS ip TEXT DEFAULT '';

-- prescriptions
ALTER TABLE public.prescriptions ADD COLUMN IF NOT EXISTS user_id TEXT;
ALTER TABLE public.prescriptions ADD COLUMN IF NOT EXISTS user_email TEXT DEFAULT '';
ALTER TABLE public.prescriptions ADD COLUMN IF NOT EXISTS image_url TEXT DEFAULT '';
ALTER TABLE public.prescriptions ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.prescriptions ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT '';

-- rider_kyc
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS rider_id BIGINT;
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS aadhaar_number TEXT DEFAULT '';
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS aadhaar_img TEXT DEFAULT '';
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS pan_number TEXT DEFAULT '';
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS pan_img TEXT DEFAULT '';
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS vehicle_rc TEXT DEFAULT '';
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS vehicle_img TEXT DEFAULT '';
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS insurance_img TEXT DEFAULT '';
ALTER TABLE public.rider_kyc ADD COLUMN IF NOT EXISTS verified BOOLEAN DEFAULT false;

-- rider_payouts
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS rider_id BIGINT;
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS name TEXT DEFAULT '';
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS contact TEXT DEFAULT '';
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS hours TEXT DEFAULT '';
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS amount NUMERIC DEFAULT 0;
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS destination TEXT DEFAULT '';
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS paid BOOLEAN DEFAULT false;
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS upi_id TEXT DEFAULT '';
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS bank_account TEXT DEFAULT '';
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS ifsc TEXT DEFAULT '';
ALTER TABLE public.rider_payouts ADD COLUMN IF NOT EXISTS paid_at TIMESTAMPTZ;

-- admin_payout_requests
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS rider_id BIGINT;
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS entity_type TEXT DEFAULT '';
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS entity_id UUID;
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS total_payout_amount NUMERIC DEFAULT 0;
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS active_duty_hours NUMERIC DEFAULT 0;
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS request_status TEXT DEFAULT 'pending';
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS requested_at TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS amount NUMERIC DEFAULT 0;
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS upi_id TEXT DEFAULT '';
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS bank_account TEXT DEFAULT '';
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS ifsc TEXT DEFAULT '';
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT '';
ALTER TABLE public.admin_payout_requests ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ;

-- payout_history
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS transaction_id TEXT DEFAULT '';
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS recipient_name TEXT DEFAULT '';
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS amount NUMERIC DEFAULT 0;
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS entity_type TEXT DEFAULT '';
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS entity_id UUID;
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS type TEXT DEFAULT '';
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS payment_method TEXT DEFAULT 'Bank Transfer';
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS method TEXT DEFAULT '';
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Completed';
ALTER TABLE public.payout_history ADD COLUMN IF NOT EXISTS reference TEXT DEFAULT '';

-- riders_wallet
ALTER TABLE public.riders_wallet ADD COLUMN IF NOT EXISTS rider_id BIGINT;
ALTER TABLE public.riders_wallet ADD COLUMN IF NOT EXISTS order_id TEXT;
ALTER TABLE public.riders_wallet ADD COLUMN IF NOT EXISTS amount_earned NUMERIC DEFAULT 0;
ALTER TABLE public.riders_wallet ADD COLUMN IF NOT EXISTS balance NUMERIC DEFAULT 0;
ALTER TABLE public.riders_wallet ADD COLUMN IF NOT EXISTS total_earned NUMERIC DEFAULT 0;
ALTER TABLE public.riders_wallet ADD COLUMN IF NOT EXISTS total_withdrawn NUMERIC DEFAULT 0;
ALTER TABLE public.riders_wallet ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'success';

-- service_zones
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS name TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS pin TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS dist TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS ps TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS muni TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS state TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS city TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS pincode TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS riders INTEGER DEFAULT 0;
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS merchants INTEGER DEFAULT 0;
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS users INTEGER DEFAULT 0;
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'approved';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS outage_message TEXT DEFAULT '';
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS outage_start TIMESTAMPTZ;
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS radius_km NUMERIC DEFAULT 10;
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS center_lat NUMERIC DEFAULT 22.5726;
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS center_lng NUMERIC DEFAULT 88.3639;
ALTER TABLE public.service_zones ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Mark existing approved medicines
UPDATE public.medicines SET admin_approved = true WHERE status IN ('Approved','Active');

-- ============================================================================
-- SECTION 7: TRIGGERS (CREATE OR REPLACE functions + DROP/CREATE triggers)
-- ============================================================================

-- Notification text sync
CREATE OR REPLACE FUNCTION public.sync_notification_text()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  new.text := coalesce(new.text, new.message);
  new.message := coalesce(new.message, new.text);
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_sync_notification_text ON public.notifications;
CREATE TRIGGER trg_sync_notification_text
BEFORE INSERT OR UPDATE ON public.notifications
FOR EACH ROW EXECUTE FUNCTION public.sync_notification_text();

-- Offer status sync
CREATE OR REPLACE FUNCTION public.sync_offer_status()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  new.active := (new.status = 'active');
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_sync_offer_status ON public.offers;
CREATE TRIGGER trg_sync_offer_status
BEFORE INSERT OR UPDATE ON public.offers
FOR EACH ROW EXECUTE FUNCTION public.sync_offer_status();

-- Merchant fields sync
CREATE OR REPLACE FUNCTION public.sync_merchant_fields()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  new.shop_name := coalesce(new.shop_name, new.merchant_name);
  new.merchant_name := coalesce(new.merchant_name, new.shop_name);
  new.address := coalesce(new.address, new.resolved_address);
  new.resolved_address := coalesce(new.resolved_address, new.address);

  IF new.license_status = 'Verified' THEN
    new.status := 'active';
  END IF;

  IF tg_op = 'UPDATE' AND old.license_status IS DISTINCT FROM new.license_status
     AND new.license_status = 'Verified' AND NOT public.is_admin() THEN
    new.license_status := old.license_status;
    new.status := old.status;
  END IF;

  new.updated_at := now();
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_sync_merchant_fields ON public.merchants;
CREATE TRIGGER trg_sync_merchant_fields
BEFORE INSERT OR UPDATE ON public.merchants
FOR EACH ROW EXECUTE FUNCTION public.sync_merchant_fields();

-- Merchant KYC verify -> auto license_status
CREATE OR REPLACE FUNCTION public.sync_merchant_verification()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF new.verified = true THEN
    UPDATE public.merchants
       SET license_status = 'Verified'
     WHERE id = new.merchant_id
       AND license_status IS DISTINCT FROM 'Verified';
  END IF;
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_sync_merchant_verification ON public.merchant_kyc;
CREATE TRIGGER trg_sync_merchant_verification
AFTER INSERT OR UPDATE ON public.merchant_kyc
FOR EACH ROW EXECUTE FUNCTION public.sync_merchant_verification();

-- Merchant KYC protect verify
CREATE OR REPLACE FUNCTION public.protect_merchant_kyc_verify()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF tg_op = 'UPDATE' AND old.verified IS DISTINCT FROM new.verified
     AND NOT public.is_admin() THEN
    new.verified := old.verified;
  END IF;
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_protect_merchant_kyc ON public.merchant_kyc;
CREATE TRIGGER trg_protect_merchant_kyc
BEFORE UPDATE ON public.merchant_kyc
FOR EACH ROW EXECUTE FUNCTION public.protect_merchant_kyc_verify();

-- Medicine fields sync + admin_approved logic
CREATE OR REPLACE FUNCTION public.sync_medicine_fields()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  new.name         := coalesce(new.name, new.product_name);
  new.product_name := coalesce(new.product_name, new.name);
  new.dosage       := coalesce(new.dosage, new.dosage_form);
  new.dosage_form  := coalesce(new.dosage_form, new.dosage);
  new.selling_price:= coalesce(new.selling_price, new.unit_price);
  new.unit_price   := coalesce(new.unit_price, new.selling_price, 0);
  new.shop_id      := coalesce(new.shop_id, new.merchant_id::text);

  IF public.is_admin() THEN
    IF new.status IN ('Approved','Active') THEN
      new.admin_approved := true;
    END IF;
  ELSE
    IF tg_op = 'INSERT' THEN
      IF new.status IN ('Approved','Active') THEN
        new.status := 'Pending';
      END IF;
      new.admin_approved := false;
    ELSE
      IF old.status IS DISTINCT FROM new.status AND new.status = 'Approved' THEN
        new.status := old.status;
      END IF;
      IF new.status = 'Active' AND NOT coalesce(old.admin_approved, false) THEN
        new.status := old.status;
      END IF;
    END IF;
  END IF;

  new.updated_at := now();
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_sync_medicine_fields ON public.medicines;
CREATE TRIGGER trg_sync_medicine_fields
BEFORE INSERT OR UPDATE ON public.medicines
FOR EACH ROW EXECUTE FUNCTION public.sync_medicine_fields();

-- Rider location sync
CREATE OR REPLACE FUNCTION public.sync_rider_location()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF new.duty_status IS NOT NULL THEN
    new.status := new.duty_status;
  END IF;
  IF new.current_lat IS NOT NULL THEN
    new.latitude := new.current_lat;
    new.longitude := new.current_lon;
  END IF;
  new.updated_at := now();
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_sync_rider_location ON public.riders;
CREATE TRIGGER trg_sync_rider_location
BEFORE INSERT OR UPDATE ON public.riders
FOR EACH ROW EXECUTE FUNCTION public.sync_rider_location();

-- Rider KYC verify -> auto is_verified
CREATE OR REPLACE FUNCTION public.sync_rider_verification()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF new.verified = true THEN
    UPDATE public.riders
       SET is_verified = true
     WHERE id = new.rider_id
       AND is_verified IS DISTINCT FROM true;
  END IF;
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_sync_rider_verification ON public.rider_kyc;
CREATE TRIGGER trg_sync_rider_verification
AFTER INSERT OR UPDATE ON public.rider_kyc
FOR EACH ROW EXECUTE FUNCTION public.sync_rider_verification();

-- Rider KYC protect verify
CREATE OR REPLACE FUNCTION public.protect_rider_kyc_verify()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF tg_op = 'UPDATE' AND old.verified IS DISTINCT FROM new.verified
     AND NOT public.is_admin() THEN
    new.verified := old.verified;
  END IF;
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_protect_rider_kyc ON public.rider_kyc;
CREATE TRIGGER trg_protect_rider_kyc
BEFORE UPDATE ON public.rider_kyc
FOR EACH ROW EXECUTE FUNCTION public.protect_rider_kyc_verify();

-- Order fields sync
CREATE OR REPLACE FUNCTION public.sync_order_fields()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  new.order_id := coalesce(new.order_id, new.id::text);
  new.pharmacy_lat := coalesce(new.pharmacy_lat, new.shop_lat);
  new.pharmacy_lon := coalesce(new.pharmacy_lon, new.shop_lng);
  new.shop_lat := coalesce(new.shop_lat, new.pharmacy_lat);
  new.shop_lng := coalesce(new.shop_lng, new.pharmacy_lon);
  new.customer_otp := coalesce(new.customer_otp, new.delivery_secure_code);
  new.delivery_secure_code := coalesce(new.delivery_secure_code, new.customer_otp);

  IF new.total_bill IS NOT NULL AND new.total_amount IS NULL THEN
    new.total_amount := nullif(regexp_replace(new.total_bill::text, '[^0-9.]', '', 'g'), '')::numeric;
  END IF;

  IF new.payment_status IS NULL AND new.status = 'Delivered' THEN
    new.payment_status := 'Paid';
  END IF;

  IF tg_op = 'INSERT' AND new.user_email IS NULL THEN
    new.user_email := auth.email();
  END IF;

  new.updated_at := now();
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_sync_order_fields ON public.orders;
CREATE TRIGGER trg_sync_order_fields
BEFORE INSERT OR UPDATE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.sync_order_fields();

-- Auto merchant payout on order completion
CREATE OR REPLACE FUNCTION public.auto_create_merchant_payout()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF new.merchant_id IS NOT NULL
     AND new.status IN ('Completed', 'Delivered')
     AND (old.status IS DISTINCT FROM new.status)
     AND NOT EXISTS (SELECT 1 FROM public.merchant_payouts WHERE order_id = new.id::text)
  THEN
    INSERT INTO public.merchant_payouts (order_id, shop_id, pickup_address, drop_address, amount, payment_mode, status)
    VALUES (
      new.id::text, new.merchant_id::text,
      coalesce(new.pharmacy_name, 'Merchant Shop'),
      coalesce(new.address, 'User Location'),
      coalesce(new.total_amount, 0),
      coalesce(new.payment_mode, 'Online Transfer'),
      'Pending'
    );
  END IF;
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_auto_merchant_payout ON public.orders;
CREATE TRIGGER trg_auto_merchant_payout
AFTER UPDATE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.auto_create_merchant_payout();

-- Fill riders_wallet rider_id
CREATE OR REPLACE FUNCTION public.fill_riders_wallet_rider_id()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF new.rider_id IS NULL AND new.order_id IS NOT NULL THEN
    SELECT rider_id INTO new.rider_id FROM public.orders WHERE id = new.order_id::uuid;
  END IF;
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_fill_wallet_rider ON public.riders_wallet;
CREATE TRIGGER trg_fill_wallet_rider
BEFORE INSERT ON public.riders_wallet
FOR EACH ROW EXECUTE FUNCTION public.fill_riders_wallet_rider_id();

-- Archive cancelled orders
CREATE OR REPLACE FUNCTION public.archive_cancelled_order()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF old.payment_status = 'Paid' THEN
    INSERT INTO public.cancelled_orders (id, customer, amount, reason, payment, status, user_email)
    VALUES (
      old.id, coalesce(old.user_name, old.user_email, 'Unknown'),
      coalesce(old.total_amount, 0), 'User cancelled order',
      coalesce(old.payment_mode, 'Online'), 'Pending', old.user_email
    ) ON CONFLICT (id) DO NOTHING;
  END IF;
  RETURN old;
END; $$;

DROP TRIGGER IF EXISTS trg_archive_cancelled_order ON public.orders;
CREATE TRIGGER trg_archive_cancelled_order
BEFORE DELETE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.archive_cancelled_order();

-- Payout request -> rider_payouts bridge
CREATE OR REPLACE FUNCTION public.copy_payout_request_to_rider_payouts()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE rname text; rcontact text; rdest text;
BEGIN
  SELECT full_name, phone, coalesce(upi_id, bank_account, 'Bank Transfer')
    INTO rname, rcontact, rdest
  FROM public.riders WHERE id = new.rider_id;

  INSERT INTO public.rider_payouts (rider_id, name, contact, hours, amount, destination, paid)
  VALUES (
    new.rider_id,
    coalesce(rname, 'Rider #' || new.rider_id::text),
    coalesce(rcontact, 'N/A'),
    coalesce(new.active_duty_hours::text, '10.0'),
    new.total_payout_amount,
    coalesce(rdest, 'Bank Transfer'),
    false
  );
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_copy_payout_request ON public.admin_payout_requests;
CREATE TRIGGER trg_copy_payout_request
AFTER INSERT ON public.admin_payout_requests
FOR EACH ROW EXECUTE FUNCTION public.copy_payout_request_to_rider_payouts();

-- KYC bridge: admin_kyc_verifications -> rider_kyc
CREATE OR REPLACE FUNCTION public.bridge_rider_kyc_submission()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r_name text; r_license text; r_plate text;
BEGIN
  SELECT full_name, license_number, vehicle_plate
    INTO r_name, r_license, r_plate
  FROM public.riders WHERE id = new.rider_id;

  INSERT INTO public.rider_kyc (rider_id, name, license_no, plate_no, license_img, plate_img, verified)
  VALUES (
    new.rider_id,
    coalesce(r_name, 'Rider #' || new.rider_id::text),
    coalesce(new.data_payload->>'license', r_license, 'N/A'),
    coalesce(new.data_payload->>'plate', r_plate, 'N/A'),
    CASE WHEN new.kyc_type = 'Driver_License' THEN 'Document Synced' ELSE null END,
    CASE WHEN new.kyc_type = 'Vehicle_Plate' THEN 'Document Synced' ELSE null END,
    false
  );
  RETURN new;
END; $$;

DROP TRIGGER IF EXISTS trg_bridge_rider_kyc ON public.admin_kyc_verifications;
CREATE TRIGGER trg_bridge_rider_kyc
AFTER INSERT ON public.admin_kyc_verifications
FOR EACH ROW EXECUTE FUNCTION public.bridge_rider_kyc_submission();

-- Merchant analytics trigger
CREATE OR REPLACE FUNCTION update_merchant_daily_analytics()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO merchant_analytics (merchant_id, date, total_orders, total_revenue, total_items_sold)
    VALUES (NEW.merchant_id, CURRENT_DATE, 1, COALESCE(NEW.total_amount, 0), 1)
    ON CONFLICT (merchant_id, date)
    DO UPDATE SET
        total_orders = merchant_analytics.total_orders + 1,
        total_revenue = merchant_analytics.total_revenue + COALESCE(NEW.total_amount, 0),
        total_items_sold = merchant_analytics.total_items_sold + 1,
        avg_order_value = (merchant_analytics.total_revenue + COALESCE(NEW.total_amount, 0)) / (merchant_analytics.total_orders + 1);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_merchant_analytics ON orders;
CREATE TRIGGER trigger_update_merchant_analytics
AFTER INSERT ON orders FOR EACH ROW EXECUTE FUNCTION update_merchant_daily_analytics();

-- Stock change logging
CREATE OR REPLACE FUNCTION log_stock_change()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.stock_qty IS DISTINCT FROM NEW.stock_qty THEN
        INSERT INTO stock_history (
            medicine_id, merchant_id, change_type, quantity_change,
            previous_stock, new_stock, reason, batch_number, performed_by
        ) VALUES (
            NEW.id, NEW.merchant_id,
            CASE
                WHEN NEW.stock_qty > OLD.stock_qty THEN 'restock'
                WHEN NEW.stock_qty < OLD.stock_qty THEN 'sale'
                ELSE 'adjustment'
            END,
            NEW.stock_qty - OLD.stock_qty,
            OLD.stock_qty,
            NEW.stock_qty,
            'Stock updated',
            NEW.batch_number,
            'system'
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_log_stock_change ON medicines;
CREATE TRIGGER trigger_log_stock_change
AFTER UPDATE ON medicines FOR EACH ROW EXECUTE FUNCTION log_stock_change();

-- Updated_at triggers for all tables
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS update_merchants_updated_at ON merchants;
CREATE TRIGGER update_merchants_updated_at BEFORE UPDATE ON merchants FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS update_medicines_updated_at ON medicines;
CREATE TRIGGER update_medicines_updated_at BEFORE UPDATE ON medicines FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS update_orders_updated_at ON orders;
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS update_riders_updated_at ON riders;
CREATE TRIGGER update_riders_updated_at BEFORE UPDATE ON riders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
DROP TRIGGER IF EXISTS update_returns_updated_at ON returns;
CREATE TRIGGER update_returns_updated_at BEFORE UPDATE ON returns FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- SECTION 8: INDEXES (only on real TABLES, not views)
-- ============================================================================

DO $$ BEGIN
CREATE INDEX IF NOT EXISTS idx_reminders_email ON public.reminders(user_email);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_merchants_auth ON public.merchants(auth_user_id);
CREATE INDEX IF NOT EXISTS idx_medicines_merchant ON public.medicines(merchant_id);
CREATE INDEX IF NOT EXISTS idx_medicines_status ON public.medicines(status);
CREATE INDEX IF NOT EXISTS idx_merchant_payouts_status ON public.merchant_payouts(status);
CREATE INDEX IF NOT EXISTS idx_riders_status ON public.riders(status);
CREATE INDEX IF NOT EXISTS idx_rider_kyc_rider ON public.rider_kyc(rider_id);
CREATE INDEX IF NOT EXISTS idx_merchant_kyc_merchant ON public.merchant_kyc(merchant_id);
CREATE INDEX IF NOT EXISTS idx_payout_history_type ON public.payout_history(type);
CREATE INDEX IF NOT EXISTS idx_orders_merchant ON public.orders(merchant_id);
CREATE INDEX IF NOT EXISTS idx_orders_rider ON public.orders(rider_id);
CREATE INDEX IF NOT EXISTS idx_orders_user_email ON public.orders(user_email);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_order_id ON public.orders(order_id);
CREATE INDEX IF NOT EXISTS idx_orders_user ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_created ON public.orders(created_at);
CREATE INDEX IF NOT EXISTS idx_rx_orders_order ON public.rx_orders(order_id);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_phone ON public.profiles(phone);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_merchants_status ON public.merchants(status);
CREATE INDEX IF NOT EXISTS idx_medicines_category ON public.medicines(category);
CREATE INDEX IF NOT EXISTS idx_riders_auth ON public.riders(auth_user_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_merchant ON public.order_items(merchant_id);
CREATE INDEX IF NOT EXISTS idx_order_items_medicine ON public.order_items(medicine_id);
CREATE INDEX IF NOT EXISTS idx_returns_merchant ON public.returns(merchant_id);
CREATE INDEX IF NOT EXISTS idx_returns_status ON public.returns(status);
CREATE INDEX IF NOT EXISTS idx_coupons_merchant ON public.coupons(merchant_id);
CREATE INDEX IF NOT EXISTS idx_coupons_code ON public.coupons(code);
CREATE INDEX IF NOT EXISTS idx_promotions_merchant ON public.promotions(merchant_id);
CREATE INDEX IF NOT EXISTS idx_stock_history_medicine ON public.stock_history(medicine_id);
CREATE INDEX IF NOT EXISTS idx_stock_history_merchant ON public.stock_history(merchant_id);
CREATE INDEX IF NOT EXISTS idx_stock_history_date ON public.stock_history(created_at);
CREATE INDEX IF NOT EXISTS idx_product_views_medicine ON public.product_views(medicine_id);
CREATE INDEX IF NOT EXISTS idx_product_views_date ON public.product_views(created_at);
CREATE INDEX IF NOT EXISTS idx_merchant_analytics_merchant ON public.merchant_analytics(merchant_id);
CREATE INDEX IF NOT EXISTS idx_merchant_analytics_date ON public.merchant_analytics(date);
CREATE INDEX IF NOT EXISTS idx_merchant_notif_merchant ON public.merchant_notifications(merchant_id);
CREATE INDEX IF NOT EXISTS idx_merchant_notif_read ON public.merchant_notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_analytics_type ON public.analytics(metric_type);
CREATE INDEX IF NOT EXISTS idx_analytics_date ON public.analytics(metric_date);
CREATE INDEX IF NOT EXISTS idx_rider_notif_rider ON public.rider_notifications(rider_id);
CREATE INDEX IF NOT EXISTS idx_products_merchant ON public.products(merchant_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON public.reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_price_history_product ON public.price_history(product_id);
CREATE INDEX IF NOT EXISTS idx_price_history_merchant ON public.price_history(merchant_id);
CREATE INDEX IF NOT EXISTS idx_patients_user_email ON public.patients(user_email);
CREATE INDEX IF NOT EXISTS idx_reminders_user_email ON public.reminders(user_email);

EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
