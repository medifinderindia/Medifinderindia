﻿-- SECTION 9: RLS â€” DROP ALL old policies, then CREATE proper ones
-- ============================================================================

DO $do$
BEGIN

-- Disable RLS on all tables first
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.patients DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.reminders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.checkups DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchants DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_kyc DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.medicines DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_alerts DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_payouts DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_kyc DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_payouts DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_kyc_verifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_payout_requests DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders_wallet DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.payout_history DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_zones DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.cancelled_orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rx_orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.returns DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupons DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_communications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_history DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_views DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_analytics DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.products DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.price_history DISABLE ROW LEVEL SECURITY;

-- Drop ALL old policies
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT schemaname, tablename, policyname
    FROM pg_policies
    WHERE schemaname = 'public'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- Now re-enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checkups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_kyc ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medicines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_payouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_kyc ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_payouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_kyc_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_payout_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders_wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payout_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cancelled_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rx_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rider_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.returns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_communications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.merchant_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.price_history ENABLE ROW LEVEL SECURITY;
-- analytics stays DISABLED (public dashboard data)

-- --- ADMIN FULL ACCESS (all tables via is_admin()) ---
DO $$
DECLARE tbl TEXT;
BEGIN
  FOR tbl IN SELECT unnest(ARRAY[
    'profiles','patients','reminders','merchants','medicines','riders',
    'orders','cancelled_orders','rx_orders','rider_kyc','rider_payouts',
    'admin_kyc_verifications','admin_payout_requests','payout_history',
    'riders_wallet','service_zones','offers','checkups','notifications',
    'merchant_kyc','merchant_alerts','merchant_payouts',
    'order_items','returns','coupons','promotions',
    'customer_communications','stock_history','product_views',
    'merchant_analytics','product_categories','merchant_notifications',
    'rider_notifications','products','reviews','price_history',
    'sponsored_products'
  ]) LOOP
    EXECUTE format('DROP POLICY IF EXISTS "Admin full access %s" ON %I', tbl, tbl);
    EXECUTE format(
      'CREATE POLICY "Admin full access %s" ON %I FOR ALL USING (is_admin())',
      tbl, tbl
    );
  END LOOP;
END $$;

-- --- PROFILES ---
DROP POLICY IF EXISTS "profiles_sel" ON public.profiles;
CREATE POLICY "profiles_sel" ON public.profiles FOR SELECT
  USING (email = auth.email() OR public.is_admin());
DROP POLICY IF EXISTS "profiles_ins" ON public.profiles;
CREATE POLICY "profiles_ins" ON public.profiles FOR INSERT
  WITH CHECK (email = auth.email());
DROP POLICY IF EXISTS "profiles_upd" ON public.profiles;
CREATE POLICY "profiles_upd" ON public.profiles FOR UPDATE
  USING (email = auth.email() OR public.is_admin());

-- --- PATIENTS ---
DROP POLICY IF EXISTS "patients_all" ON public.patients;
CREATE POLICY "patients_all" ON public.patients FOR ALL
  USING (user_email = auth.email() OR public.is_admin())
  WITH CHECK (user_email = auth.email() OR public.is_admin());

-- --- REMINDERS ---
DROP POLICY IF EXISTS "reminders_all" ON public.reminders;
CREATE POLICY "reminders_all" ON public.reminders FOR ALL
  USING (user_email = auth.email() OR public.is_admin())
  WITH CHECK (user_email = auth.email() OR public.is_admin());

-- --- NOTIFICATIONS ---
DROP POLICY IF EXISTS "notif_sel" ON public.notifications;
CREATE POLICY "notif_sel" ON public.notifications FOR SELECT USING (true);
DROP POLICY IF EXISTS "notif_ins" ON public.notifications;
CREATE POLICY "notif_ins" ON public.notifications FOR INSERT
  WITH CHECK (public.is_admin());

-- --- CHECKUPS ---
DROP POLICY IF EXISTS "checkups_ins" ON public.checkups;
CREATE POLICY "checkups_ins" ON public.checkups FOR INSERT
  WITH CHECK ((SELECT auth.uid()) IS NOT NULL);
DROP POLICY IF EXISTS "checkups_sel" ON public.checkups;
CREATE POLICY "checkups_sel" ON public.checkups FOR SELECT
  USING (public.is_admin());

-- --- OFFERS ---
DROP POLICY IF EXISTS "offers_sel" ON public.offers;
CREATE POLICY "offers_sel" ON public.offers FOR SELECT USING (true);

-- --- MERCHANTS ---
DROP POLICY IF EXISTS "merchants_sel" ON public.merchants;
CREATE POLICY "merchants_sel" ON public.merchants FOR SELECT
  USING (auth_user_id = auth.uid() OR email = auth.email() OR public.is_admin());
DROP POLICY IF EXISTS "merchants_ins" ON public.merchants;
CREATE POLICY "merchants_ins" ON public.merchants FOR INSERT
  WITH CHECK (auth_user_id = auth.uid() OR email = auth.email());
DROP POLICY IF EXISTS "merchants_upd" ON public.merchants;
CREATE POLICY "merchants_upd" ON public.merchants FOR UPDATE
  USING (auth_user_id = auth.uid() OR email = auth.email() OR public.is_admin());

-- --- MERCHANT_KYC ---
DROP POLICY IF EXISTS "mkyc_sel" ON public.merchant_kyc;
CREATE POLICY "mkyc_sel" ON public.merchant_kyc FOR SELECT
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "mkyc_ins" ON public.merchant_kyc;
CREATE POLICY "mkyc_ins" ON public.merchant_kyc FOR INSERT
  WITH CHECK (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "mkyc_upd" ON public.merchant_kyc;
CREATE POLICY "mkyc_upd" ON public.merchant_kyc FOR UPDATE
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));

-- --- MEDICINES ---
DROP POLICY IF EXISTS "meds_sel" ON public.medicines;
CREATE POLICY "meds_sel" ON public.medicines FOR SELECT
  USING (status IN ('Approved','Active') OR public.is_admin()
    OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "meds_all" ON public.medicines;
CREATE POLICY "meds_all" ON public.medicines FOR ALL
  USING (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()))
  WITH CHECK (public.is_admin() OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));

-- --- MERCHANT_ALERTS ---
DROP POLICY IF EXISTS "malert_sel" ON public.merchant_alerts;
CREATE POLICY "malert_sel" ON public.merchant_alerts FOR SELECT USING (true);

-- --- MERCHANT_PAYOUTS ---
DROP POLICY IF EXISTS "mpay_sel" ON public.merchant_payouts;
CREATE POLICY "mpay_sel" ON public.merchant_payouts FOR SELECT
  USING (public.is_admin() OR shop_id IN (SELECT id::text FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "mpay_upd" ON public.merchant_payouts;
CREATE POLICY "mpay_upd" ON public.merchant_payouts FOR UPDATE USING (public.is_admin());

-- --- RIDERS ---
DROP POLICY IF EXISTS "riders_sel" ON public.riders;
CREATE POLICY "riders_sel" ON public.riders FOR SELECT
  USING (public.is_admin() OR auth_user_id = auth.uid() OR email = auth.email() OR status = 'online');
DROP POLICY IF EXISTS "riders_ins" ON public.riders;
CREATE POLICY "riders_ins" ON public.riders FOR INSERT
  WITH CHECK (auth_user_id = auth.uid() OR email = auth.email());
DROP POLICY IF EXISTS "riders_upd" ON public.riders;
CREATE POLICY "riders_upd" ON public.riders FOR UPDATE
  USING (auth_user_id = auth.uid() OR email = auth.email() OR public.is_admin());

-- --- RIDER_KYC ---
DROP POLICY IF EXISTS "rkyc_sel" ON public.rider_kyc;
CREATE POLICY "rkyc_sel" ON public.rider_kyc FOR SELECT
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "rkyc_ins" ON public.rider_kyc;
CREATE POLICY "rkyc_ins" ON public.rider_kyc FOR INSERT
  WITH CHECK (rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "rkyc_upd" ON public.rider_kyc;
CREATE POLICY "rkyc_upd" ON public.rider_kyc FOR UPDATE USING (public.is_admin());

-- --- RIDER_PAYOUTS ---
DROP POLICY IF EXISTS "rpay_sel" ON public.rider_payouts;
CREATE POLICY "rpay_sel" ON public.rider_payouts FOR SELECT
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "rpay_upd" ON public.rider_payouts;
CREATE POLICY "rpay_upd" ON public.rider_payouts FOR UPDATE USING (public.is_admin());

-- --- ADMIN_KYC_VERIFICATIONS ---
DROP POLICY IF EXISTS "akyc_sel" ON public.admin_kyc_verifications;
CREATE POLICY "akyc_sel" ON public.admin_kyc_verifications FOR SELECT
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "akyc_ins" ON public.admin_kyc_verifications;
CREATE POLICY "akyc_ins" ON public.admin_kyc_verifications FOR INSERT
  WITH CHECK (rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "akyc_upd" ON public.admin_kyc_verifications;
CREATE POLICY "akyc_upd" ON public.admin_kyc_verifications FOR UPDATE USING (public.is_admin());

-- --- ADMIN_PAYOUT_REQUESTS ---
DROP POLICY IF EXISTS "areq_sel" ON public.admin_payout_requests;
CREATE POLICY "areq_sel" ON public.admin_payout_requests FOR SELECT
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "areq_ins" ON public.admin_payout_requests;
CREATE POLICY "areq_ins" ON public.admin_payout_requests FOR INSERT
  WITH CHECK (rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));

-- --- RIDERS_WALLET ---
DROP POLICY IF EXISTS "rw_sel" ON public.riders_wallet;
CREATE POLICY "rw_sel" ON public.riders_wallet FOR SELECT
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "rw_ins" ON public.riders_wallet;
CREATE POLICY "rw_ins" ON public.riders_wallet FOR INSERT
  WITH CHECK ((SELECT auth.uid()) IS NOT NULL);

-- --- PAYOUT_HISTORY ---
DROP POLICY IF EXISTS "ph_sel" ON public.payout_history;
CREATE POLICY "ph_sel" ON public.payout_history FOR SELECT USING (public.is_admin());
DROP POLICY IF EXISTS "ph_ins" ON public.payout_history;
CREATE POLICY "ph_ins" ON public.payout_history FOR INSERT WITH CHECK (public.is_admin());

-- --- SERVICE_ZONES ---
DROP POLICY IF EXISTS "sz_sel" ON public.service_zones;
CREATE POLICY "sz_sel" ON public.service_zones FOR SELECT USING (true);

-- --- ORDERS ---
DROP POLICY IF EXISTS "orders_sel" ON public.orders;
CREATE POLICY "orders_sel" ON public.orders FOR SELECT
  USING (public.is_admin() OR user_email = auth.email()
    OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email())
    OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "orders_ins" ON public.orders;
CREATE POLICY "orders_ins" ON public.orders FOR INSERT
  WITH CHECK (true);
DROP POLICY IF EXISTS "orders_upd" ON public.orders;
CREATE POLICY "orders_upd" ON public.orders FOR UPDATE
  USING (public.is_admin() OR user_email = auth.email()
    OR merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid() OR email = auth.email())
    OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "orders_del" ON public.orders;
CREATE POLICY "orders_del" ON public.orders FOR DELETE
  USING (public.is_admin() OR user_email = auth.email());

-- --- CANCELLED_ORDERS ---
DROP POLICY IF EXISTS "co_sel" ON public.cancelled_orders;
CREATE POLICY "co_sel" ON public.cancelled_orders FOR SELECT
  USING (public.is_admin() OR user_email = auth.email());
DROP POLICY IF EXISTS "co_upd" ON public.cancelled_orders;
CREATE POLICY "co_upd" ON public.cancelled_orders FOR UPDATE USING (public.is_admin());

-- --- RX_ORDERS ---
DROP POLICY IF EXISTS "rx_sel" ON public.rx_orders;
CREATE POLICY "rx_sel" ON public.rx_orders FOR SELECT
  USING (public.is_admin());
DROP POLICY IF EXISTS "rx_ins" ON public.rx_orders;
CREATE POLICY "rx_ins" ON public.rx_orders FOR INSERT
  WITH CHECK ((SELECT auth.uid()) IS NOT NULL);
DROP POLICY IF EXISTS "rx_upd" ON public.rx_orders;
CREATE POLICY "rx_upd" ON public.rx_orders FOR UPDATE USING (public.is_admin());

-- --- RIDER_NOTIFICATIONS ---
DROP POLICY IF EXISTS "rn_sel" ON public.rider_notifications;
CREATE POLICY "rn_sel" ON public.rider_notifications FOR SELECT
  USING (public.is_admin() OR rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid() OR email = auth.email()));
DROP POLICY IF EXISTS "rn_ins" ON public.rider_notifications;
CREATE POLICY "rn_ins" ON public.rider_notifications FOR INSERT
  WITH CHECK (public.is_admin());

-- --- PARTNER_MEDICINES (view) â€” no RLS needed, underlying tables have RLS

-- --- PUBLIC READ for public tables ---
DROP POLICY IF EXISTS "Public read merchants" ON public.merchants;
CREATE POLICY "Public read merchants" ON public.merchants FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public read offers" ON public.offers;
CREATE POLICY "Public read offers" ON public.offers FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public read service_zones" ON public.service_zones;
CREATE POLICY "Public read service_zones" ON public.service_zones FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public read products" ON public.products;
CREATE POLICY "Public read products" ON public.products FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public read reviews" ON public.reviews;
CREATE POLICY "Public read reviews" ON public.reviews FOR SELECT USING (true);

-- --- MERCHANT OWN DATA policies ---
DROP POLICY IF EXISTS "Merchants manage own medicines" ON public.medicines;
CREATE POLICY "Merchants manage own medicines" ON public.medicines FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage own orders" ON public.orders;
CREATE POLICY "Merchants manage own orders" ON public.orders FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage order_items" ON public.order_items;
CREATE POLICY "Merchants manage order_items" ON public.order_items FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage returns" ON public.returns;
CREATE POLICY "Merchants manage returns" ON public.returns FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage coupons" ON public.coupons;
CREATE POLICY "Merchants manage coupons" ON public.coupons FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage promotions" ON public.promotions;
CREATE POLICY "Merchants manage promotions" ON public.promotions FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage stock_history" ON public.stock_history;
CREATE POLICY "Merchants manage stock_history" ON public.stock_history FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage merchant_analytics" ON public.merchant_analytics;
CREATE POLICY "Merchants manage merchant_analytics" ON public.merchant_analytics FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage merchant_notifications" ON public.merchant_notifications;
CREATE POLICY "Merchants manage merchant_notifications" ON public.merchant_notifications FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage merchant_kyc" ON public.merchant_kyc;
CREATE POLICY "Merchants manage merchant_kyc" ON public.merchant_kyc FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage merchant_alerts" ON public.merchant_alerts;
CREATE POLICY "Merchants manage merchant_alerts" ON public.merchant_alerts FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage merchant_payouts" ON public.merchant_payouts;
CREATE POLICY "Merchants manage merchant_payouts" ON public.merchant_payouts FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage offers" ON public.offers;
CREATE POLICY "Merchants manage offers" ON public.offers FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage product_views" ON public.product_views;
CREATE POLICY "Merchants manage product_views" ON public.product_views FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage product_categories" ON public.product_categories;
CREATE POLICY "Merchants manage product_categories" ON public.product_categories FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Merchants manage customer_communications" ON public.customer_communications;
CREATE POLICY "Merchants manage customer_communications" ON public.customer_communications FOR ALL
  USING (merchant_id IN (SELECT id FROM public.merchants WHERE auth_user_id = auth.uid()));

-- --- RIDER OWN DATA policies ---
DROP POLICY IF EXISTS "Riders manage own data" ON public.riders;
CREATE POLICY "Riders manage own data" ON public.riders FOR ALL USING (auth_user_id = auth.uid());
DROP POLICY IF EXISTS "Riders manage own kyc" ON public.rider_kyc;
CREATE POLICY "Riders manage own kyc" ON public.rider_kyc FOR ALL
  USING (rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Riders manage own payouts" ON public.rider_payouts;
CREATE POLICY "Riders manage own payouts" ON public.rider_payouts FOR ALL
  USING (rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Riders manage own wallet" ON public.riders_wallet;
CREATE POLICY "Riders manage own wallet" ON public.riders_wallet FOR ALL
  USING (rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid()));
DROP POLICY IF EXISTS "Riders manage own notifications" ON public.rider_notifications;
CREATE POLICY "Riders manage own notifications" ON public.rider_notifications FOR ALL
  USING (rider_id IN (SELECT id FROM public.riders WHERE auth_user_id = auth.uid()));

-- --- USER OWN DATA policies ---
DROP POLICY IF EXISTS "Users manage own profile" ON public.profiles;
CREATE POLICY "Users manage own profile" ON public.profiles FOR ALL USING (auth.uid()::text = id);

EXCEPTION WHEN OTHERS THEN NULL;
END $do$;

-- ============================================================================
-- SECTION 10: REALTIME PUBLICATION
-- ============================================================================
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'service_zones','rider_payouts','rider_kyc','riders',
    'medicines','merchant_payouts','merchant_kyc','merchants',
    'payout_history','cancelled_orders','rx_orders','orders',
    'admin_kyc_verifications','admin_payout_requests',
    'rider_notifications','notifications','offers',
    'profiles','patients','reminders',
    'order_items','returns','stock_history',
    'merchant_notifications','products','reviews','price_history'
  ] LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN NULL;
    END;
  END LOOP;
END $$;

-- ============================================================================
-- SECTION 11: STORAGE BUCKETS
-- ============================================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true) ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public)
VALUES ('user-prescriptions', 'user-prescriptions', true) ON CONFLICT (id) DO NOTHING;

-- Storage policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "avatars_public_read" ON storage.objects;
  CREATE POLICY "avatars_public_read" ON storage.objects FOR SELECT
    USING (bucket_id = 'avatars');
  DROP POLICY IF EXISTS "avatars_auth_upload" ON storage.objects;
  CREATE POLICY "avatars_auth_upload" ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'avatars' AND (SELECT auth.uid()) IS NOT NULL);
  DROP POLICY IF EXISTS "avatars_auth_update" ON storage.objects;
  CREATE POLICY "avatars_auth_update" ON storage.objects FOR UPDATE
    USING (bucket_id = 'avatars' AND (SELECT auth.uid()) IS NOT NULL);
  DROP POLICY IF EXISTS "avatars_admin_delete" ON storage.objects;
  CREATE POLICY "avatars_admin_delete" ON storage.objects FOR DELETE
    USING (bucket_id = 'avatars' AND (public.is_admin() OR (SELECT auth.uid()) IS NOT NULL));
  DROP POLICY IF EXISTS "prescriptions_public_read" ON storage.objects;
  CREATE POLICY "prescriptions_public_read" ON storage.objects FOR SELECT
    USING (bucket_id = 'user-prescriptions');
  DROP POLICY IF EXISTS "prescriptions_auth_upload" ON storage.objects;
  CREATE POLICY "prescriptions_auth_upload" ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'user-prescriptions' AND (SELECT auth.uid()) IS NOT NULL);
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

