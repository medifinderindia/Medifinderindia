-- ============================================================================
-- MIGRATION 004: Sponsored Products (for adminsponsored.html)
-- SAFE TO RUN MULTIPLE TIMES — all CREATE IF NOT EXISTS
-- ============================================================================

-- SECTION A: TABLE
CREATE TABLE IF NOT EXISTS public.sponsored_products (
    id BIGSERIAL PRIMARY KEY,
    title TEXT DEFAULT '',
    subtitle TEXT DEFAULT '',
    tag TEXT DEFAULT 'SPONSORED',
    gradient TEXT DEFAULT 'linear-gradient(135deg, #e02020, #ff6b6b)',
    icon_class TEXT DEFAULT 'fa-solid fa-capsules',
    btn_text TEXT DEFAULT 'Shop Now',
    btn_action TEXT DEFAULT '',
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- SECTION B: ADD COLUMN IF NOT EXISTS (for existing tables from earlier runs)
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS title TEXT DEFAULT '';
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS subtitle TEXT DEFAULT '';
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS tag TEXT DEFAULT 'SPONSORED';
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS gradient TEXT DEFAULT 'linear-gradient(135deg, #e02020, #ff6b6b)';
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS icon_class TEXT DEFAULT 'fa-solid fa-capsules';
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS btn_text TEXT DEFAULT 'Shop Now';
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS btn_action TEXT DEFAULT '';
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS sort_order INT DEFAULT 0;
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE public.sponsored_products ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- SECTION C: UPDATED_AT TRIGGER
DROP TRIGGER IF EXISTS update_sponsored_updated_at ON public.sponsored_products;
CREATE TRIGGER update_sponsored_updated_at
    BEFORE UPDATE ON public.sponsored_products
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- SECTION D: RLS (drop old policies first, then recreate)
ALTER TABLE public.sponsored_products DISABLE ROW LEVEL SECURITY;

DO $$
DECLARE r record;
BEGIN
    FOR r IN
        SELECT policyname FROM pg_policies
        WHERE schemaname = 'public' AND tablename = 'sponsored_products'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.sponsored_products', r.policyname);
    END LOOP;
END $$;

ALTER TABLE public.sponsored_products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read sponsored" ON public.sponsored_products
    FOR SELECT USING (is_active = true OR public.is_admin());

CREATE POLICY "Admin manage sponsored" ON public.sponsored_products
    FOR ALL USING (public.is_admin());

-- SECTION E: DEMO DATA (only if table is empty)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM public.sponsored_products LIMIT 1) THEN
        INSERT INTO public.sponsored_products (title, subtitle, tag, gradient, icon_class, btn_text, btn_action, sort_order, is_active) VALUES
        ('Vitamin D3 Booster 60K IU', '50% OFF — Limited Time', 'NEW LAUNCH', 'linear-gradient(135deg, #e02020, #ff6b6b)', 'fa-solid fa-sun', 'Shop Now', '', 1, true),
        ('Baby Care Complete Kit', 'Flat 30% OFF + Free Delivery', 'BESTSELLER', 'linear-gradient(135deg, #6c5ce7, #a29bfe)', 'fa-solid fa-baby', 'Grab Deal', '', 2, true),
        ('Diabetes Care Glucometer', 'Starting from ₹299 only', 'TRENDING', 'linear-gradient(135deg, #00b894, #55efc4)', 'fa-solid fa-syringe', 'Order Now', '', 3, true);
    END IF;
END $$;

-- SECTION F: REALTIME publication (safe — only adds if not present)
DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS public.sponsored_products;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;
