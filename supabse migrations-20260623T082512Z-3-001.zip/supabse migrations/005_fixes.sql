-- ============================================================================
-- 005_fixes.sql — Missing triggers, indexes, RLS policies, and columns
-- Idempotent — safe to run multiple times
-- ============================================================================

-- ============================================================================
-- 1. PRESCRIPTIONS TABLE RLS — was enabled but had ZERO policies
-- ============================================================================
DO $do$ BEGIN
    DROP POLICY IF EXISTS "prescriptions_all" ON public.prescriptions;
    CREATE POLICY "prescriptions_all" ON public.prescriptions FOR ALL
      USING (user_id = auth.uid()::text OR public.is_admin())
      WITH CHECK (user_id = auth.uid()::text OR public.is_admin());
EXCEPTION WHEN OTHERS THEN NULL;
END $do$;

-- ============================================================================
-- 2. PRODUCTS TABLE — missing updated_at trigger
-- ============================================================================
DO $do$ BEGIN
    DROP TRIGGER IF EXISTS update_products_updated_at ON public.products;
    CREATE TRIGGER update_products_updated_at
      BEFORE UPDATE ON public.products
      FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
EXCEPTION WHEN OTHERS THEN NULL;
END $do$;

-- ============================================================================
-- 3. MERCHANT_KYC — add missing verified_at and rejected_at columns
-- ============================================================================
DO $$ BEGIN
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ;
    ALTER TABLE public.merchant_kyc ADD COLUMN IF NOT EXISTS license_img TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
-- 4. MISSING INDEXES for performance
-- ============================================================================
DO $$ BEGIN
    CREATE INDEX IF NOT EXISTS idx_cancelled_orders_order_id ON public.cancelled_orders(order_id);
    CREATE INDEX IF NOT EXISTS idx_cancelled_orders_user_email ON public.cancelled_orders(user_email);
    CREATE INDEX IF NOT EXISTS idx_rider_payouts_rider_id ON public.rider_payouts(rider_id);
    CREATE INDEX IF NOT EXISTS idx_admin_kyc_rider_id ON public.admin_kyc_verifications(rider_id);
    CREATE INDEX IF NOT EXISTS idx_admin_kyc_status ON public.admin_kyc_verifications(status);
    CREATE INDEX IF NOT EXISTS idx_admin_payout_rider_id ON public.admin_payout_requests(rider_id);
    CREATE INDEX IF NOT EXISTS idx_merchant_alerts_merchant_id ON public.merchant_alerts(merchant_id);
    CREATE INDEX IF NOT EXISTS idx_service_zones_pin ON public.service_zones(pin);
    CREATE INDEX IF NOT EXISTS idx_sponsored_products_active ON public.sponsored_products(is_active);
    CREATE INDEX IF NOT EXISTS idx_sponsored_products_sort ON public.sponsored_products(sort_order);
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
-- 5. RIDERS_WALLET — missing updated_at trigger
-- ============================================================================
DO $do$ BEGIN
    DROP TRIGGER IF EXISTS update_riders_wallet_updated_at ON public.riders_wallet;
    CREATE TRIGGER update_riders_wallet_updated_at
      BEFORE UPDATE ON public.riders_wallet
      FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
EXCEPTION WHEN OTHERS THEN NULL;
END $do$;

-- ============================================================================
-- 6. RIDER_NOTIFICATIONS — add target column if missing
-- ============================================================================
DO $$ BEGIN
    ALTER TABLE public.rider_notifications ADD COLUMN IF NOT EXISTS target TEXT DEFAULT 'all';
    ALTER TABLE public.rider_notifications ADD COLUMN IF NOT EXISTS sent_by TEXT DEFAULT 'admin';
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
-- 7. ORDERS — add updated_at column if missing
-- ============================================================================
DO $$ BEGIN
    ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
EXCEPTION WHEN OTHERS THEN NULL;
END $$;
